<?php
include 'conn.php';

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $crewName = $_POST['crew-name'];
    $crewEmail = $_POST['email'];
    $phone = $_POST['phone'];
    $crewSize = (int)$_POST['crew-size'];
    $specialSkills = $_POST['special-skills'];

    $crewinfo = $conn->prepare('INSERT INTO event_crew (crew_Name, crew_Leader, email, phone, special_skills) VALUES (?, ?, ?, ?, ?)');
    if ($crewinfo) {
        $crewinfo->bind_param("sssis", $crewName, $crewEmail, $phone, $crewSize, $specialSkills);

        if ($crewinfo->execute()) {
            echo "<script>alert('Crew registered successfully!');</script>";
        } else {
            echo "<script>alert('Error: " . $crewinfo->error . "');</script>";
        }
        $crewinfo->close();
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crew Registration</title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- CSS Links -->
    <link rel="stylesheet" href="../assets/css/crewregistration.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <p class="prof" onclick="proflogout()"><?php echo $_SESSION['username'] ?></p>
                <div class="log-out" id="profid">
                    <a href="./logout.php">
                        <p><i class="fas fa-sign-out-alt"></i> LogOut</p>
                    </a>
                </div>
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <section class="crew-registration">
            <h1>Crew Registration</h1>
            <p>Join our team of dedicated crew members and help make our events a success!</p>
            <form action="" method="post">
                <label for="crew-name">Crew Name:</label>
                <input type="text" id="crew-name" name="crew-name" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="phone">Phone:</label>
                <input type="tel" id="phone" name="phone" required>

                <label for="crew-size">Crew Size:</label>
                <input type="number" id="crew-size" name="crew-size" required>

                <label for="special-skills">Special Skills:</label>
                <textarea id="special-skills" name="special-skills"></textarea>

                <button type="submit">Register Crew</button>
            </form>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.php">Careers</a></li>
                    <li><a href="#">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="../html/faqs.html">FAQs</a></li>
                    <li><a href="../php/user-contacts.php">Help Center</a></li>
                    <li><a href="../php/user-contacts.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="../php/user_index.php">Home</a></li>
                    <li><a href="../php/user_events.php">Events</a></li>
                    <li><a href="../php/user_calendar.php">Calendar</a></li>
                    <li><a href="../php/user_aboutus.php">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SimEvents. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>
    <script>
        // Dynamic footer date
        document.getElementById("date").textContent = new Date().getFullYear();
    </script>
</body>

</html>