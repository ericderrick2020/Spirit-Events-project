<div class="event-card-info-pos">
                            <div class="event-card-document">
                                <h3><?php echo htmlspecialchars($event['event_name']) ?></h3>
                                <p><i class="fa-solid fa-location-dot"></i> Lugogo Cricket Oval </p>
                            </div>
                            <div class="event-card-button">
                                <time datetime=""><i class="fa-solid fa-calendar-days"></i> July 15-17,2025</time>
                            </div>
                        </div>