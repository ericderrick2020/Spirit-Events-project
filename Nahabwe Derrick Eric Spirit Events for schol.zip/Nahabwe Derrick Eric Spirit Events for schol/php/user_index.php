<?php
include 'conn.php';
session_start();

// Redirect to login if the user is not logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}


// Prepare a statement to fetch the user profile
$query = $conn->prepare("SELECT * FROM users WHERE username = ?");
$query->bind_param("s", $_SESSION['username']);
$query->execute();

// Fetch the result correctly
$outcome = $query->get_result();  // Correct function name is get_result() (lowercase "r")

// For cards: Execute a query to fetch event information
$query_2 = "SELECT event_id, event_images, event_name, event_date, event_location, event_category, event_description FROM events";
$results_of_query_2 = $conn->query($query_2);

if (!$results_of_query_2) {
    die("Error fetching events: " . $conn->error);
}

$conn->close();
?>


<!-- https://via.placeholder.com/300x200 -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- WEBSITE TITLE -->
    <title>Home | Spirit Events</title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/index.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <p class="prof" onclick="proflogout()"><?php echo $_SESSION['username'] ?></p>
                <div class="log-out" id="profid">
                    <a href="./logout.php">
                        <p><i class="fas fa-sign-out-alt"></i> LogOut</p>
                    </a>
                </div>
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
    <main>
        <!-- HERO SECTION START -->
        <section class="hero-section">
            <div class="hero-sec-bgc">
                <div class="hero-sec-bgc-1">
                    <h1>WE ARE SPIRIT EVENTS</h1>
                    <p>Join us for an inspiring Christian event filled with worship, powerful teachings, and fellowship
                        as we come together to celebrate faith and hope</p>
                    <br>
                    <button class="btn">Get Tickets</button>
                </div>
                <div class="hero-sec-bgc-2">
                    <img src="../assets/img/sim.png" alt="Rectangle Placeholder Image">
                </div>
            </div>
        </section>
        <!-- HERO SECTION CLOSE -->

        <!-- FEATURED EVENTS START -->
        <section class="featured-events">
            <h2>Upcoming Events</h2>
            <br>
            <div class="event-cards-container">
                <div class="slideshow-container">
                    <?php
                    $limit = 3; // Set the limit for the number of slides
                    $count = 0;

                    // Assuming you have a database query result in $results_of_query_2
                    while ($event = $results_of_query_2->fetch_assoc()):
                        if ($count >= $limit) {
                            break; // Stop the loop if the limit is reached
                        }
                    ?>
                        <!-- Full-width images with number and caption text -->
                        <div class="mySlides fade">
                            <div class="numbertext"><?php echo ($count + 1) . " / " . $limit; ?></div>
                            <img src="<?php echo htmlspecialchars($event['event_images']); ?>" style="width:100%">
                            <div class="text"><?php echo htmlspecialchars($event['event_caption']); ?></div>
                            <a href="user_event_details.php?id=${event.event_id}" class="ticket-btn"> Learn More
                            </a>
                        </div>
                    <?php
                        $count++;
                    endwhile;
                    ?>

                    <!-- Next and previous buttons -->
                    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                    <a class="next" onclick="plusSlides(1)">&#10095;</a>
                </div>

                <br>

                <!-- The dots/circles -->
                <div class="dot-container" style="text-align:center">
                    <?php for ($i = 1; $i <= $limit; $i++): ?>
                        <span class="dot" onclick="currentSlide(<?php echo $i; ?>)"></span>
                    <?php endfor; ?>
                </div>
            </div>

        </section>
        <!-- UPCOMING EVENTS END -->

        <!-- COMMENT SECTION OPEN -->
        <!-- <section class="comment-section">
            <div class="comment-section">
                <div class="comment-cards">

                </div>
            </div>
        </section> -->
        <!-- COMMENT SECTION CLOSE -->

    </main>
    <!-- FOOTER START(i used the include statement to include the footer same to any part) -->
    <?php include '../php/partials/footer.php' ?>
    <!-- FOOTER END -->
    <!-- JAVASCRIPT LINKS -->
    <script src="../assets/js/index.js"></script>
</body>

</html>