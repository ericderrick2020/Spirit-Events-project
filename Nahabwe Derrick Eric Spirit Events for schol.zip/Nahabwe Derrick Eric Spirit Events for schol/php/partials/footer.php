    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.php">Careers</a></li>
                    <li><a href="#">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="../html/faqs.html">FAQs</a></li>
                    <li><a href="../php/user-contacts.php">Help Center</a></li>
                    <li><a href="../php/user-contacts.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="../php/user_index.php">Home</a></li>
                    <li><a href="../php/user_events.php">Events</a></li>
                    <li><a href="../php/user_calendar.php">Calendar</a></li>
                    <li><a href="../php/user_aboutus.php">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SimEvents. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>