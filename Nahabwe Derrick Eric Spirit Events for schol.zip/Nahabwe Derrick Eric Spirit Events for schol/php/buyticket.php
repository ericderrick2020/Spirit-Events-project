<?php
// (Optional) Database connection
// $conn = new mysqli('localhost', 'root', '', 'event_db');
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// Hard-coded seat options as fallback (can come from a database query)
// $seat_options = [
//     ['type' => 'Ordinary Seat', 'price' => 45000],
//     ['type' => 'VIP Seat', 'price' => 150000]
// ];

// Function to format price (e.g., with commas)
function format_price($amount)
{
    return 'SHS ' . number_format($amount, 0);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="../assets/css/buyticket.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <p class="prof" onclick="proflogout()"><?php echo $_SESSION['username'] ?></p>
                <div class="log-out" id="profid">
                    <a href="./logout.php">
                        <p><i class="fas fa-sign-out-alt"></i> LogOut</p>
                    </a>
                </div>
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>

    <main>
        <section class="buy-ticket-section">
            <h1>Spirit Vibes</h1>
            <p>Join us for a night of music, worship, and inspiration!</p>

            <div class="event-payment-container">
                <?php foreach ($seat_options as $seat): ?>
                    <div class="event-payment-card">
                        <div class="event-card-side-1">
                            <h3><?php echo $seat['type']; ?></h3>
                            <p>Enjoy the best experience with this seat type.</p>
                            <span><?php echo format_price($seat['price']); ?></span>
                        </div>
                        <div class="event-card-side-2">
                            <form action="process_payment.php" method="POST">
                                <label for="tickets">Number of Tickets</label>
                                <input type="number" name="tickets" min="1" value="1" required>
                                <input type="hidden" name="seat_type" value="<?php echo $seat['type']; ?>">
                                <input type="hidden" name="seat_price" value="<?php echo $seat['price']; ?>">
                                <button type="submit">Buy Now</button>
                                <button type="submit" formaction="add_to_cart.php">Add to Cart</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.html">Careers</a></li>
                    <li><a href="sponsors.html">Sponsors</a></li>
                </ul>
            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#"><i class="fa-brands fa-x-twitter"></i></a>
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <p>&copy; <span id="date"></span> SPIRIT EVENTS. All rights reserved.</p>
    </footer>

    <script>
        // Display the current year
        document.getElementById("date").textContent = new Date().getFullYear();
    </script>
</body>

</html>