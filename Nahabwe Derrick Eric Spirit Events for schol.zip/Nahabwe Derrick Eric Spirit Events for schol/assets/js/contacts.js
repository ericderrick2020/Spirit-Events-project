function sendMessage() {
    // Simulate sending a message
    const messageSent = true; // This should be based on your logic

    if (messageSent) {
        // Show success message
        alert("Message sent successfully!");
    }
}