-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: event_logins
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_1_categories`
--

DROP TABLE IF EXISTS `event_1_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_1_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1_categories`
--

LOCK TABLES `event_1_categories` WRITE;
/*!40000 ALTER TABLE `event_1_categories` DISABLE KEYS */;
INSERT INTO `event_1_categories` VALUES (1,'rich',77777.00);
/*!40000 ALTER TABLE `event_1_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1_tickets`
--

DROP TABLE IF EXISTS `event_1_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_1_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_1_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1_tickets`
--

LOCK TABLES `event_1_tickets` WRITE;
/*!40000 ALTER TABLE `event_1_tickets` DISABLE KEYS */;
INSERT INTO `event_1_tickets` VALUES (1,NULL,'9514',300000.00,NULL,'ticket_d37cd15f02c867238e13df2ee5d88264.png','2024-11-08 18:07:00'),(2,NULL,'8761',933324.00,NULL,'ticket_32a19a3dfbe0ac91878175964cf1dd57.png','2024-11-08 18:20:15'),(3,NULL,'3996',388885.00,NULL,'ticket_ec6ba588c61c1077e48d93974b79beed.png','2024-11-08 19:19:48'),(4,NULL,'7544',311108.00,NULL,'ticket_520861d07919a3672f8f309fcd968893.png','2024-11-09 10:48:10'),(5,NULL,'1740',155554.00,NULL,'ticket_db369a4dc70757918ea6c6625fdaf1b8.png','2024-11-10 19:14:23'),(6,NULL,'5063',155554.00,NULL,NULL,'2024-11-10 19:22:10'),(7,NULL,'3311',388885.00,NULL,NULL,'2024-11-10 20:16:33');
/*!40000 ALTER TABLE `event_1_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_2_categories`
--

DROP TABLE IF EXISTS `event_2_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_2_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_2_categories`
--

LOCK TABLES `event_2_categories` WRITE;
/*!40000 ALTER TABLE `event_2_categories` DISABLE KEYS */;
INSERT INTO `event_2_categories` VALUES (1,'VVIP',50000.00);
/*!40000 ALTER TABLE `event_2_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_2_tickets`
--

DROP TABLE IF EXISTS `event_2_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_2_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_2_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_2_tickets`
--

LOCK TABLES `event_2_tickets` WRITE;
/*!40000 ALTER TABLE `event_2_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_2_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_crew`
--

DROP TABLE IF EXISTS `event_crew`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_crew` (
  `crew_Name` varchar(500) DEFAULT NULL,
  `crew_Leader` varchar(500) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `event_interest` varchar(500) NOT NULL,
  `crew_size` int DEFAULT NULL,
  `special_skills` varchar(900) DEFAULT NULL,
  PRIMARY KEY (`event_interest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_crew`
--

LOCK TABLES `event_crew` WRITE;
/*!40000 ALTER TABLE `event_crew` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_crew` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `event_id` int NOT NULL AUTO_INCREMENT,
  `event_images` varchar(900) DEFAULT NULL,
  `event_name` varchar(100) NOT NULL,
  `event_date` date DEFAULT NULL,
  `event_location` varchar(100) DEFAULT NULL,
  `event_category` varchar(400) DEFAULT NULL,
  `event_description` longtext,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `event_category` (`event_category`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'../assets/img/uploads/rew.png','Computer Gala','2024-11-02','kampala Uganda',NULL,'Once upon a time, in a small but technologically forward-thinking town, the annual CodeCraze competition was fast approaching. It was the most anticipated event among young programmers, known for challenging the participants\' coding skills, creativity, and endurance.\r\n\r\nThis year, a group of friends—Liam, Sofia, Ray, and Maya—decided to enter as a team. Each of them had a unique strength: Liam was a master of algorithms, Sofia was the CSS and design wizard, Ray knew databases inside out, and Maya could debug code like a pro. They had been practicing together, spending late nights brainstorming and solving tricky problems in preparation for the big day.\r\n\r\nThe competition began early on a Saturday morning, with dozens of teams seated in front of rows of computers in the town’s tech center. The first challenge was to build a simple game that could engage players for a minimum of five minutes. The clock was ticking as each team feverishly typed away, racing against time.\r\n\r\nLiam and Sofia quickly designed the game concept—a fast-paced puzzle game with a bright, colorful interface that would appeal to a wide range of players. Ray set up the database to store high scores, while Maya debugged each feature as it was implemented, ensuring everything ran smoothly.\r\n\r\nThe judges were impressed with their game and awarded them full points for creativity and functionality. But that was only the beginning.\r\n\r\nThe second challenge was a problem-solving round, where each team had to create a piece of software to analyze and visualize a large dataset. The task was particularly challenging, as the data was complex and included thousands of entries. Liam and Ray worked on algorithms to sort and clean the data, while Sofia crafted a beautiful interface to display the charts and graphs. Maya meticulously tested every visualization, catching a critical bug just minutes before the deadline.\r\n\r\nTheir tool turned out to be one of the most user-friendly and insightful in the competition, winning the judges over once again.\r\n\r\nFinally, they reached the last round: a live debugging session, where each team was handed a code filled with bugs. The fastest team to fix the errors and make the code functional would win the grand prize. Maya’s skills were the star of this round. She kept her cool, quickly spotting and fixing each bug with precision, while her teammates cheered her on.\r\n\r\nAfter hours of intense competition, the scores were tallied, and it was announced: Liam, Sofia, Ray, and Maya’s team had won first place! Their teamwork, dedication, and diverse skills had carried them to victory. As they held up their trophy, they felt proud of what they had accomplished together.','2024-11-07 18:27:53','2024-11-07 18:27:53',NULL,NULL),(2,'../assets/img/uploads/Screenshot 2024-11-01 230057.png','SQL zzzzz','2024-11-03','3rcc3r',NULL,'fvevfevefvfefevvefevfvfevefefefefvvfevefefefvfevvefveffvefve','2024-11-08 13:24:44','2024-11-08 13:24:44',NULL,NULL);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_contacts`
--

DROP TABLE IF EXISTS `message_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_contacts` (
  `email` varchar(259) DEFAULT NULL,
  `subjects` longtext,
  `messages` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_contacts`
--

LOCK TABLES `message_contacts` WRITE;
/*!40000 ALTER TABLE `message_contacts` DISABLE KEYS */;
INSERT INTO `message_contacts` VALUES ('biggiecyber@gmail.com','mistake','vhrthtrhththwhthwtrhtthwthhtwhrthhrwhth'),('biggiecyber@gmail.com','mistake','ddfdsdsfds'),('biggiecyber@gmail.com','mistake','luyrxtugcouyitculyflguvui'),('biggiecyber@gmail.com','mistake','yrfxcuvckfyhviubicgjhfvkijibuyfvy hjkmooikljhg  tuxdgctgvhboughfycf iydutcgvbhinolh.jkgjv  utdgloudyrtuiojpj;lkkv lyccutg'),('biggiecyber@gmail.com','mistake','yrfxcuvckfyhviubicgjhfvkijibuyfvy hjkmooikljhg  tuxdgctgvhboughfycf iydutcgvbhinolh.jkgjv  utdgloudyrtuiojpj;lkkv lyccutg'),('biggiecyber@gmail.com','mistake','ugcuv'),('biggiecyber@gmail.com','mistake','ugcuv'),('biggiecyber@gmail.com','mistake','ugcuv'),('biggiecyber@gmail.com','mistake','ugcuv'),('biggiecyber@gmail.com','mistake','ugcuv'),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL);
/*!40000 ALTER TABLE `message_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `profile_image` varchar(600) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `first_name` varchar(500) DEFAULT NULL,
  `last_name` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (16,NULL,'ec2020','ericderrick2020@gmail.com','$2y$10$dDjz2t4jHlDri6j/2ds5gezKUrAjjt2QyAbCkj2NFLX.h.6VbxLry','2024-10-22 06:45:43','2024-10-22 06:45:43','Derrick','eric'),(17,NULL,'ks','biggiecyber@gmail.com','$2y$10$tGzJgDTgAM332MD9M9oxFumQ40vd.lN..XzCmQDJhlWSK.aUT7yby','2024-10-24 07:18:46','2024-10-24 07:18:46','kasolo','dickson');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-11  6:32:00
