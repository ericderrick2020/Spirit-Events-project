<?php
// Include the database connection file
require '../php/conn.php';
session_start();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collecting data from the form
    $eventname = $_POST['event-name'];
    $eventdate = $_POST['date'];
    $event_location = $_POST['Location-name'];
    $event_description = $_POST['describe'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $venueCosts = $_POST['venueCost'] ?? [];
    $venueCategories = $_POST['venueCategory'] ?? [];

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $targetDir = "../assets/img/uploads/";
        $targetFile = $targetDir . basename($_FILES['image']['name']);

        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            // Insert the event into the events table
            $stmt = $conn->prepare(
                "INSERT INTO events (event_images, event_name, event_date, event_location, event_description, start_time, end_time) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $stmt->bind_param("sssssss", $targetFile, $eventname, $eventdate, $event_location, $event_description, $start_time, $end_time);

            if ($stmt->execute()) {
                $eventId = $conn->insert_id;  // Get the last inserted event ID

                // Create a new table for this event's categories
                $newTableName = "event_{$eventId}_categories";
                $createTableQuery = "
                    CREATE TABLE $newTableName (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        category_name VARCHAR(255),
                        cost DECIMAL(10,2)
                    )
                ";

                if ($conn->query($createTableQuery) === TRUE) {
                    // Insert categories into the new table
                    $insertQuery = "INSERT INTO $newTableName (category_name, cost) VALUES (?, ?)";
                    $categoryStmt = $conn->prepare($insertQuery);

                    foreach ($venueCategories as $index => $venueCategory) {
                        $venueCost = $venueCosts[$index] ?? 0;
                        $categoryStmt->bind_param("sd", $venueCategory, $venueCost);
                        if (!$categoryStmt->execute()) {
                            echo "Error adding category: " . $categoryStmt->error;
                        }
                    }

                    // Create a separate ticket table for the event
                    $ticketTableName = "event_{$eventId}_tickets";
                    $createTicketTableQuery = "
                        CREATE TABLE $ticketTableName (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            user_id INT,
                            ticket_id VARCHAR(255),
                            amount DECIMAL(10,2),
                            payment_method VARCHAR(50),
                            qr_code VARCHAR(255),
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                        )
                    ";

                    if ($conn->query($createTicketTableQuery) === TRUE) {
                        // Ticket table created successfully
                        header("Location: ./dashboard_event.php");
                        exit();
                    } else {
                        echo "Error creating ticket table: " . $conn->error;
                    }

                    $categoryStmt->close();
                } else {
                    echo "Error creating categories table: " . $conn->error;
                }
            } else {
                echo "Error adding event: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Error moving uploaded file.";
        }
    } else {
        echo "Error uploading image.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dasboard_general.css">
    <script defer src="../assets/js/dashboard_general.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard_add_event.css">
</head>

<body>
    <div class="dashboard">
        <nav class="top-bar">
            <h1>Events Dashboard</h1>
        </nav>

        <nav class="sidebar">
            <ul class="nav-links">
                <li><a href="dashboard_home.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="dashboard_event.php"><i class="fas fa-calendar-alt"></i> Event Planning</a></li>
                <li><a href="dashboard_attendence.php"><i class="fas fa-ticket-alt"></i> Attendance</a></li>
            </ul>
        </nav>
        <div class="content-side">
            <form method="post" enctype="multipart/form-data">
                <div class="add-event-forms">
                    <div class="add-event-page-container-1">
                        <div id="imageDisplay">Image preview here</div>
                        <input type="file" name="image" id="imageInput" accept="image/*" required>
                    </div>
                    <div class="add-event-page-container-2">
                        <div class="row-1">
                            <label for="event-name">Event Name</label>
                            <input type="text" name="event-name" id="event-name" required>
                        </div>
                        <div class="row-1">
                            <label for="date">Date</label>
                            <input type="date" name="date" id="date" required>
                        </div>
                        <div class="row-1">
                            <label for="time">Time Start</label>
                            <input type="time" name="starttime" id="time">
                            <label for="time">Time End</label>
                            <input type="time" name="endtime" id="time">

                        </div>
                        <div class="row-1">
                            <label for="Location-name">Location</label>
                            <input type="text" name="Location-name" id="Location-name" required>
                        </div>
                        <div class="row-1">
                            <div id="addBtn">Create Category</div>
                            <table>
                                <tbody id="inputContainer"></tbody>
                            </table>
                        </div>
                        <div class="row-1">
                            <label for="describe">Description</label>
                            <textarea name="describe" id="describe" required></textarea>
                        </div>
                        <button type="submit" name="submit">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script src="../assets/js/dashboard_add_event.js"></script>
</body>

</html>