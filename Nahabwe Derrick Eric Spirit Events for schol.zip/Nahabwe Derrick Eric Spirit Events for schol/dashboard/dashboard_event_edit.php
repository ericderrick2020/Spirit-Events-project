<?php
require '../php/conn.php';
session_start();

// Initialize variables to hold event data
$eventId = $eventname = $eventdate = $event_location = $event_description = $image_path = "";

// Check if an event ID is provided
if (isset($_GET['event-id'])) {
    $eventId = $_GET['event-id'];

    // Fetch existing event data from the database
    $sql = "SELECT event_images, event_name, event_date, event_location, event_description FROM events WHERE event_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $eventname = $row['event_name'];
        $eventdate = $row['event_date'];
        $event_location = $row['event_location'];
        $event_description = $row['event_description'];
        $image_path = $row['event_images']; // Save current image path for editing
    } else {
        echo "No existing event found.";
        exit();
    }
    $stmt->close();
} else {
    echo "No event ID provided.";
    exit();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collecting data from form
    $eventId = $_POST['event-id'];
    $eventname = $_POST['event-name'];
    $eventdate = $_POST['date'];
    $event_location = $_POST['Location-name'];
    $event_description = $_POST['describe'];

    // Check if a new image has been uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] != UPLOAD_ERR_NO_FILE) {
        if ($_FILES['image']['error'] == UPLOAD_ERR_OK) {
            $targetDir = "../assets/img/uploads/";
            $targetFile = $targetDir . basename($_FILES['image']['name']);

            // Move the uploaded file to the target directory
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                echo "Error moving uploaded file.";
                exit();
            } else {
                $image_path = $targetFile; // Set the new image path
            }
        } else {
            echo "Error uploading image: " . $_FILES['image']['error'];
            exit();
        }
    }

    // Update the event in the database
    $sql = "UPDATE events SET event_images = ?, event_name = ?, event_date = ?, event_location = ?, event_description = ? WHERE event_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $image_path, $eventname, $eventdate, $event_location, $event_description, $eventId);

    if ($stmt->execute()) {
        // Redirect to the events dashboard after a successful update
        header("Location: ./dashboard_event.php");
        exit();
    } else {
        echo "Error updating record: " . $stmt->error; // Use this to debug SQL errors
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dasboard_general.css">
    <script defer src="../assets/js/dashboard_general.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard_add_event.css">
</head>

<body>
    <div class="dashboard">
        <nav class="top-bar">
            <h1>Events Dashboard</h1>
        </nav>

        <nav class="sidebar">
            <ul class="nav-links">
                <li><a href="dashboard_home.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="dashboard_event.php"><i class="fas fa-calendar-alt"></i> Event Planning</a></li>
                <li><a href="dashboard_attendence.php"><i class="fas fa-ticket-alt"></i> Attendance</a></li>
                <!-- <li><a href="#"><i class="fas fa-money-bill-wave"></i> QR Code Scanner</a></li>
                <li><a href="#"><i class="fas fa-users"></i> Analytics</a></li>
                <li><a href="#"><i class="fas fa-chart-line"></i> Reports</a></li>
                <li><a href="#"><i class="fa fa-plus"></i> Add Blogs</a></li> -->
            </ul>
        </nav>
        <div class="content-side">
            <form method="post" enctype="multipart/form-data">
                <div class="add-event-forms">
                    <div class="add-event-page-container-1">
                        <div id="imageDisplay">Image preview here</div>
                        <input type="file" name="image" id="imageInput" accept="image/*">
                    </div>
                    <div class="add-event-page-container-2">
                        <input type="hidden" name="event-id" value="<?php echo htmlspecialchars($eventId); ?>">
                        <div class="row-1">
                            <label for="event-name">Event Name</label>
                            <input type="text" name="event-name" id="event-name" value="<?php echo htmlspecialchars($eventname); ?>" required>
                        </div>
                        <div class="row-1">
                            <label for="date">Date</label>
                            <input type="date" name="date" id="date" value="<?php echo htmlspecialchars($eventdate); ?>" required>
                        </div>
                        <div class="row-1">
                            <label for="time-start">Time Start</label>
                            <input type="time" name="starttime" id="time-start">
                            <label for="time-end">Time End</label>
                            <input type="time" name="endtime" id="time-end">
                        </div>
                        <div class="row-1">
                            <label for="Location-name">Location</label>
                            <input type="text" name="Location-name" id="Location-name" value="<?php echo htmlspecialchars($event_location); ?>" required>
                        </div>
                        <div class="row-1">
                            <div id="addBtn">Create Category</div>
                            <table>
                                <tbody id="inputContainer"></tbody>
                            </table>
                        </div>
                        <div class="row-1">
                            <label for="describe">Description</label>
                            <textarea name="describe" id="describe" required><?php echo htmlspecialchars($event_description); ?></textarea>
                        </div>
                        <button type="submit" name="submit">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script src="../assets/js/dashboard_add_event.js"></script>
</body>

</html>