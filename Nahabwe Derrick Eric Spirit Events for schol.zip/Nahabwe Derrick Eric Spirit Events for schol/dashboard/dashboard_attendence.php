<?php
require '../php/conn.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collecting data from form
    $eventname = $_POST['event-name'];
    $eventdate = $_POST['date'];
    $event_location = $_POST['Location-name'];
    $event_description = $_POST['describe'];
    $venueNames = $_POST['venueName'] ?? [];
    $venueCosts = $_POST['venueCost'] ?? [];
    $venueCategories = $_POST['venueCategory'] ?? [];

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $targetDir = "../assets/img/uploads/"; // Ensure this directory exists and is writable
        $targetFile = $targetDir . basename($_FILES['image']['name']); // Get the file path

        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            // Insert event data into the events table
            $stmt = $conn->prepare(
                "INSERT INTO events (event_images, event_name, event_date, event_location, event_description) 
                 VALUES (?, ?, ?, ?, ?)"
            );
            $stmt->bind_param("sssss", $targetFile, $eventname, $eventdate, $event_location, $event_description);

            if ($stmt->execute()) {
                // If the event is inserted, insert venue/category data
                $eventId = $conn->insert_id; // Get the last inserted event ID
                $venueStmt = $conn->prepare(
                    "INSERT INTO event_category_table (category_title, prices) 
                     VALUES (?, ?)"
                );

                foreach ($venueNames as $index => $venueName) {
                    $venueCost = $venueCosts[$index] ?? 0;
                    $venueCategory = $venueCategories[$index] ?? '';

                    $venueStmt->bind_param("sd", $venueCategory, $venueCost);
                    if (!$venueStmt->execute()) {
                        echo "Error adding venue: " . $venueStmt->error;
                    }
                }

                echo "Event and venues added successfully!";
            } else {
                echo "Error adding event: " . $stmt->error;
            }

            // Close statements
            $stmt->close();
            $venueStmt->close(); // Ensure this line is not commented

            // Redirect to the form page
            header("Location: ./dashboard_event.php");
            exit();
        } else {
            echo "Error moving uploaded file.";
        }
    } else {
        echo "Error uploading image.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dasboard_general.css">
    <script defer src="../assets/js/dashboard_general.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard_attendence.css">
</head>

<body>
    <div class="dashboard">
        <nav class="top-bar">
            <h1>Events Dashboard</h1>
        </nav>

        <nav class="sidebar">
            <ul class="nav-links">
                <li><a href="dashboard_home.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="dashboard_event.php"><i class="fas fa-calendar-alt"></i> Event Planning</a></li>
                <li><a href="dashboard_attendence.php"><i class="fas fa-ticket-alt"></i> Attendance</a></li>
            </ul>
        </nav>
        <div class="content-side">
            <section class="section-1">
                <h2>Bookings / Ticketing Overview</h2>
                <div class="section-1-cards">
                    <div class="summary-cards">
                        <span class="card-name">Total Sales</span>
                        <span class="card-digit">Shs.25000000</span>
                    </div>
                    <div class="summary-cards">
                        <span class="card-name">Tickets Sold</span>
                        <span class="card-digit">1,250</span>
                    </div>
                    <div class="summary-cards">
                        <span class="card-name">Available Tickets</span>
                        <span class="card-digit">750</span>
                    </div>
                </div>
            </section>
            <section class="section-2">
                <div class="top-of-section-2">
                    <h3>Recent Bookings</h3>
                    <input type="text" name="SearchBar" id="searchbar" placeholder="Search...">
                </div>
                <div class="section-2-booking-list">
                    <table>
                        <thead>
                            <tr>
                                <th>Ticket No.</th>
                                <th>Name</th>
                                <th>Event</th>
                                <th>No.of Tickets</th>
                                <th>Date</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>EV1001</td>
                                <td>derrick</td>
                                <td>ggggg</td>
                                <td>5</td>
                                <td>01 - 01 - 2024</td>
                                <td>Shs. 50000</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
    <script src="../assets/js/dashboard_attendence.js"></script>
</body>

</html>