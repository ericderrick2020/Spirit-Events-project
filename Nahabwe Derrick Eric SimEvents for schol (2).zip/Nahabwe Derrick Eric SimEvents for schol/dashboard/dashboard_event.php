<?php
require '../php/conn.php';
session_start();

// Fetch events from the database, including event_id
$sql = "SELECT event_id, event_images, event_name, event_date, event_location, event_description FROM events";
$result = mysqli_query($conn, $sql);

$sql1 = "SELECT COUNT(DISTINCT event_name) AS event_counts FROM events";
$result1 = $conn->query($sql1);
if ($result1) {
    $noOfUsers1 = $result1->fetch_assoc()['event_counts'] ?? 0;
}



$sql2 = "SELECT COUNT(DISTINCT event_name) AS upcomingEvents FROM events WHERE event_date > CURDATE()";
$update = $conn->query($sql2);

if ($update) {
    $upcomingEventsCount = $update->fetch_assoc()['upcomingEvents'] ?? 0;
    echo "Number of upcoming events: " . $upcomingEventsCount;
} else {
    echo "Error: " . $conn->error;
}

$conn->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dasboard_general.css">
    <script defer src="../assets/js/dashboard_general.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard_event.css">
</head>

<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <nav class="top-bar">
            <h1>Events Dashboard</h1>
        </nav>

        <nav class="sidebar">
            <ul class="nav-links">
                <li><a href="dashboard_home.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="dashboard_event.php"><i class="fas fa-calendar-alt"></i> Event Planning</a></li>
                <li><a href="dashboard_attendence.php"><i class="fas fa-ticket-alt"></i> Attendance</a></li>
            </ul>
        </nav>

        <!-- CONTENT SIDE OPEN -->
        <div class="content-side">
            <section class="quick-cards">
                <div class="quick-cards-container">
                    <div class="dashboard-view-card">
                        <span class="heading-cards">Total Event</span>
                        <span class="card-numbers" style="color: blue;"><?php echo $noOfUsers1 ?></span>
                    </div>
                    <div class="dashboard-view-card">
                        <span class="heading-cards">Upcoming Events</span>
                        <span class="card-numbers" style="color: blue;"><?php echo $upcomingEventsCount ?></span>
                    </div>
                    <div class="dashboard-view-card">
                        <span class="heading-cards">Tick</span>
                        <span class="card-numbers" style="color: blue;"></span>
                    </div>
                </div>
            </section>
            <section class="event-dashboard-view">
                <div class="quick-actions-buttons-events">
                    <a href="./dashboard_add_event.php"><button><i class="fas fa-plus-circle"></i> Create Event</button></a>
                </div>
            </section>
            <section class="event-table">
                <h2>Upcoming events</h2>
                <table>
                    <thead>
                        <tr>
                            <td>EVENT NAME</td>
                            <td>DATE</td>
                            <td>LOCATION</td>
                            <td>OPTIONS</td>
                        </tr>
                    </thead>
                    <?php if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tbody>
                                <tr>
                                    <td><?php echo $row['event_name'] ?></td>
                                    <td><?php echo $row['event_date'] ?></td>
                                    <td><?php echo $row['event_location'] ?></td>
                                    <td>
                                        <a href="dashboard_event_edit.php?id=<?php echo $row['event_id']; ?>"><button style="background-color: green;"><i class="fas fa-edit"></i> Edit</button></a>
                                        <form action="./delete_event_for_dashboard.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="id" value="<?php echo $row['event_id']; ?>">
                                            <button type="submit" onclick="return confirm('Are you sure you want to delete this event?')" style="background-color: red;">
                                                <i class="fas fa-trash"></i> DELETE
                                            </button>
                                        </form>

                                    </td>
                                </tr>
                            </tbody>
                        <?php }
                    } else { ?>

                        <th rowspan="4" style="padding: 20px; font-size:30px; padding-left: 30px;">No events found!</th>

                    <?php } ?>
                </table>
            </section>

        </div>
    </div>
</body>

</html>