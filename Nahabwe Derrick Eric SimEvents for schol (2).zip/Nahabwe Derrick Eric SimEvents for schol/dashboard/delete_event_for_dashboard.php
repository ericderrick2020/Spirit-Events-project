<?php
require '../php/conn.php';
session_start();

if (!isset($_POST['id'])) {
    die("ID not provided.");
}

$id = $_POST['id'];  // Event ID

// Start a transaction to ensure all operations succeed or fail together
$conn->begin_transaction();

try {
    // Dynamically determine the category table name for the event
    $categoryTable = "event_{$id}_categories";

    // Step 1: Drop the event-specific category table
    $dropCategoryTableSql = "DROP TABLE IF EXISTS $categoryTable";
    if (!$conn->query($dropCategoryTableSql)) {
        throw new Exception("Error deleting category table: " . $conn->error);
    }

    // Step 2: Delete associated records from the shared categories table (if any)
    $deleteCategoriesSql = "DELETE FROM categories WHERE event_id = ?";
    $categoryStmt = $conn->prepare($deleteCategoriesSql);
    $categoryStmt->bind_param("i", $id);
    $categoryStmt->execute();
    $categoryStmt->close();

    // Step 3: Delete the event from the events table
    $deleteEventSql = "DELETE FROM events WHERE event_id = ?";
    $eventStmt = $conn->prepare($deleteEventSql);
    $eventStmt->bind_param("i", $id);

    if ($eventStmt->execute()) {
        // Commit the transaction if all operations are successful
        $conn->commit();
        header("Location: ./dashboard_event.php");
        exit(); // Stop further script execution after redirect
    } else {
        throw new Exception("Error deleting event: " . $eventStmt->error);
    }

    $eventStmt->close();
} catch (Exception $e) {
    // Roll back the transaction if any operation fails
    $conn->rollback();
    echo "Transaction failed: " . $e->getMessage();
}

$conn->close();
?>
