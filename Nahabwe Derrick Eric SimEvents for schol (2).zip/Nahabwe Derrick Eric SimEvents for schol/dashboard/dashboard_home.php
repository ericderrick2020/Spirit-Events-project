<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Database connection credentials
$host = '127.0.0.1';
$username = 'root'; // Replace if necessary
$password = 'ericderrick2020'; // Replace if necessary
$dbname = 'event_logins'; // Replace with your database name

// Create the MySQL connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Execute the query to get the number of users
$sql = "SELECT COUNT(username) AS user_count FROM users";
$result = $conn->query($sql);

// Query to get the number of events
$sql1 = "SELECT COUNT(DISTINCT event_name) AS event_counts FROM events";
$result1 = $conn->query($sql1);

// Query to get event details
$sql2 = "SELECT event_name, event_date FROM events ORDER BY event_date ASC LIMIT 5"; // Limit to 5 upcoming events
$result2 = $conn->query($sql2);

// Check if the query executed successfully
if ($result) {
    $noOfUsers = $result->fetch_assoc()['user_count'] ?? 0;
} else {
    die("Query failed: " . $conn->error);
}

if ($result1) {
    $noOfUsers1 = $result1->fetch_assoc()['event_counts'] ?? 0;
} else {
    die("Query failed: " . $conn->error);
}

// Fetch events data
$events = [];
if ($result2) {
    while ($row = $result2->fetch_assoc()) {
        $events[] = $row; // Store each event in an array
    }
} else {
    die("Query failed: " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dasboard_general.css">
    <script defer src="../assets/js/dashboard_general.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard_home.css">
</head>

<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <nav class="top-bar">
            <h1>Events Dashboard</h1>
        </nav>

        <nav class="sidebar">
            <ul class="nav-links">
                <li><a href="dashboard_home.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="dashboard_event.php"><i class="fas fa-calendar-alt"></i> Event Planning</a></li>
                <li><a href="dashboard_attendence.php"><i class="fas fa-ticket-alt"></i> Attendance</a></li>
            </ul>
        </nav>

        <!-- Content Side -->
        <main>
            <div class="content-side">
                <section class="dashboard-view">
                    <h2>Dashboard Overview</h2>
                    <div class="dashboard-cards-home">
                        <div class="dashboard-view-card">
                            <span class="heading-cards"> Total Users</span>
                            <span class="card-numbers" style="color: blue;"><?php echo $noOfUsers ?></span>
                        </div>
                        <div class="dashboard-view-card">
                            <span class="heading-cards">Total Attendees</span>
                            <span class="card-numbers" style="color: green;">1,234</span>
                        </div>
                        <div class="dashboard-view-card">
                            <span class="heading-cards">Total Events</span>
                            <span class="card-numbers" style="color: purple;"><?php echo $noOfUsers1 ?></span>
                        </div>
                    </div>
                </section>
                <section class="dashboard-view-coming-from-home">
                    <br>
                    <h2>Upcoming Events</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Event Name</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($events as $event) : ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($event['event_name']); ?></td>
                                    <td><?php echo htmlspecialchars($event['event_date']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </section>
            </div>
        </main>
    </div>
</body>

</html>