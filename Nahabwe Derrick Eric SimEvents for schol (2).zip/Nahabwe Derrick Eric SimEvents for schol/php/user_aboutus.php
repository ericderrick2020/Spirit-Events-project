<?php
include 'conn.php'; // Include the database connection file
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- WEBSITE TITLE -->
    <title>About Us | Spirit Events</title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/aboutus.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <p class="prof" onclick="proflogout()"><?php echo $_SESSION['username'] ?></p>
                <div class="log-out" id="profid">
                    <a href="./logout.php">
                        <p><i class="fas fa-sign-out-alt"></i> LogOut</p>
                    </a>
                </div>
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
    <!-- HERO SECTION START -->
    <main>
        <!-- ABOUT US HERO SECTION START -->
        <section class="hero-section-about-us" id="hero-section-about-us">
            <div class="hero-section-about-us-container">
                <h1>About SimEvents</h1>
                <p>Welcome to SimEvents – the place where the party never ends and the vibes are always high! We create unforgettable events that bring people together for a great time, incredible energy, and pure fun. Whether it's epic hangouts, exciting activities, or just good vibes with amazing people, we’re all about creating an atmosphere filled with joy, laughter, and connection. Come join the celebration, feel the beat, and let loose with us – because life is better when we’re all having fun together!</p>

                <br>
                <img src="../assets/img/image6-min.png" alt="">
            </div>
        </section>
        <!-- ABOUT US HERO SECTION END -->
        <section class="hero-section-our-mission">
            <h1>Our Mission</h1>
            <p>Our mission is to spread good vibes, positivity, and excitement by building a dynamic community that encourages personal growth, new friendships, and unforgettable experiences. We’re all about creating opportunities for people to connect, have fun, and celebrate life together. Whether it's through awesome events, exciting activities, or simply hanging out with like-minded people, we aim to empower individuals to live their best lives and share the joy with everyone around them!</p>

        </section>
        <!-- MEET OUR TEAM START -->
        <section class="meet-our-team" id="team">
            <h1>Meet Our Team Leaders</h1>
            <div class="meet-our-team-profile">
                <div class="team-card">
                    <img src="../assets/img/uifaces-popular-image (1).jpg" alt="">
                    <h3>Gilbert Rogers</h3>
                    <span>CEO</span>
                </div>

                <div class="team-card">
                    <img src="../assets/img/uifaces-popular-image.jpg" alt="">
                    <h3>Hillson Geofrey</h3>
                    <span>Assistant Leader</span>
                </div>

                <div class="team-card">
                    <img src="../assets/img/uifaces-popular-image (2).jpg" alt="">
                    <h3>Martha Richson</h3>
                    <span>SECRETARY</span>
                </div>
            </div>
        </section>
        <!-- MEET OUR TEAM END -->

        <!-- OUR VALUES START -->
        <section class="our-values" id="values">
            <h1>Our Values</h1>
            <div class="our-values-container">
                <div class="our-values-cards">
                    <h3>Innovation</h3>
                    <p>Revolutionizing the way we connect, create, and celebrate through exciting events, cutting-edge tech, and community-driven fun. We’re all about pushing boundaries and sparking new ideas to keep things fresh, inspiring, and full of energy!</p>
                </div>


                <div class="our-values-cards">
                    <h3>Collaboration</h3>
                    <p>Bringing together diverse talents and big personalities to create a stronger, more vibrant community. We believe in teamwork, sharing ideas, and amplifying each other’s strengths to make things happen – together!</p>
                </div>


                <div class="our-values-cards">
                    <h3>Excellence</h3>
                    <p>Pushing ourselves to the next level in everything we do – from amazing service to unforgettable events and creating lasting connections. We aim to bring our best every time, making sure everything we do is top-notch and full of energy!</p>
                </div>

                <div class="our-values-cards">
                    <h3>Sustainability</h3>
                    <p>Going green and making a positive impact! We’re all about creating a future where everyone can thrive by embracing eco-friendly practices, protecting the planet, and doing our part to keep the world in balance. Let’s make sustainability the new cool!</p>
                </div>


            </div>
        </section>
        <!-- OUR VALUES END -->
        <!-- NEWSLETTER START -->
        <section class="send-our-newsletter">
            <div class="send-our-newsletter-container">
                <h2>SUBSCRIBE TO OUR NEWSLETTER</h2>
                <p>Stay up with the latest updates in Spirit Events</p>
                <form action="" method="post">
                    <input type="email" name="email" id="email" placeholder="Enter your Email">
                    <button type="submit" onclick="messagereceived()">Subscribe</button>
                </form>
            </div>
        </section>

        <!-- NEWSLETTER END -->
    </main>
    <!-- FOOTER START -->
    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.php">Careers</a></li>
                    <li><a href="#">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="../html/faqs.html">FAQs</a></li>
                    <li><a href="../php/user-contacts.php">Help Center</a></li>
                    <li><a href="../php/user-contacts.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="../php/user_index.php">Home</a></li>
                    <li><a href="../php/user_events.php">Events</a></li>
                    <li><a href="../php/user_calendar.php">Calendar</a></li>
                    <li><a href="../php/user_aboutus.php">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SimEvents. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>
    <!-- FOOTER END -->
    <!-- JAVASCRIPT LINKS -->
    <script src="../assets/js/aboutus.js"></script>
    <script src="../assets/js/navbarandfooter.js"></script>
</body>

</html>