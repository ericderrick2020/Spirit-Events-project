<?php
include 'conn.php';
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
            </div>
            <p><?php echo $_SESSION['username']?></p>
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
</body>

</html>