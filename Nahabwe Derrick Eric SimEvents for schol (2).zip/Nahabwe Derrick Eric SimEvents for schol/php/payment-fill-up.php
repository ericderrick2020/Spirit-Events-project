<?php
require 'conn.php';
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

// Retrieve the event details
$amount = isset($_GET['amount']) ? intval($_GET['amount']) : 0;
$event_id = isset($_GET['event_id']) ? intval($_GET['event_id']) : 1;

// Fetch the event name based on the event_id
$eventName = "Unknown Event"; // default if the event is not found
$eventQuery = $conn->prepare("SELECT event_name FROM events WHERE event_id = ?");
$eventQuery->bind_param("i", $event_id);
$eventQuery->execute();
$eventQuery->bind_result($eventName);
$eventQuery->fetch();
$eventQuery->close();

if (isset($_POST['submitPayment'])) {
    $fullName = $_POST['fullName'];
    $noOfTickets = intval($_POST['ticketnos']);
    $paymentMethod = $_POST['pgate'];
    $amountPaid = $amount * $noOfTickets;
    $ticketID = rand(1000, 9999);
    $email = $_POST['email'];

    // Dynamically set the ticket table name based on the event ID
    $ticketTableName = "event_{$event_id}_tickets";

    // Check if the ticket table exists; if not, create it
    $createTicketTableQuery = "
        CREATE TABLE IF NOT EXISTS $ticketTableName (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            ticket_id VARCHAR(255),
            amount DECIMAL(10,2),
            payment_method VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    ";

    if ($conn->query($createTicketTableQuery) === FALSE) {
        die("Error creating ticket table: " . $conn->error);
    }

    // Prepare the SQL query to insert into the event's ticket table
    $stmt = $conn->prepare("INSERT INTO $ticketTableName (ticket_id, user_id, amount, payment_method, created_at) VALUES (?, ?, ?, ?, NOW())");

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind parameters and execute the statement
    $stmt->bind_param("siss", $ticketID, $_SESSION['user_id'], $amountPaid, $paymentMethod);

    if ($stmt->execute()) {
        // Redirect to the user receipt page with ticket details
        header("Location: user-receipt-page.php?ticketID=$ticketID&event_id=$event_id&eventName=" . urlencode($eventName) . "&amountPaid=$amountPaid&fullName=" . urlencode($fullName));
        exit;
    } else {
        echo "Failed to store ticket. Please try again.";
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- WEBSITE TITLE -->
    <title>Home </title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/payment-fill-up.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <p class="prof" onclick="proflogout()"><?php echo $_SESSION['username'] ?></p>
                <div class="log-out" id="profid">
                    <a href="./logout.php">
                        <p><i class="fas fa-sign-out-alt"></i> LogOut</p>
                    </a>
                </div>
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
    <!-- HERO SECTION START -->

    <main>
        <div class="payment-field-container">
            <h2>Enter Payment Information</h2>
            <div class="pay-list-container">
                <div class="pay-opt">
                    <img src="../assets/img/mobile-money.svg" alt="">
                    <h3>Mobile Pay</h3>
                </div>
                <div class="pay-opt">
                    <img src="../assets/img/card-icon.png" alt="">
                    <h3>Card Pay</h3>
                </div>
            </div>
            <form method="post">
                <div class="mobile-pay hidden" id="mob-pay">
                    <h2>Mobile Pay</h2>

                    <div class="fill-up">
                        <label for="fname">Enter Name to appear on Ticket</label>
                        <input type="text" name="fullName" id="fname" required>
                    </div>
                    <div class="fill-up">
                        <label for="ticketnos">Number of Tickets</label>
                        <input type="number" name="ticketnos" id="ticketnos" min="1" required onchange="updateTotal()" oninput="updateTotal()">
                    </div>
                    <div class="fill-up">
                        <label for="telno">Enter Number</label>
                        <input type="text" name="telno" id="telno" required>
                    </div>
                    <button type="submit" name="submitPayment">PAY NOW UGX <span id="totalAmountDisplay2"><?php echo number_format($amount, 2); ?></span></button>
                </div>
            </form>
        </div>
        </form>
        <script>
            function updateTotal() {
                const ticketCount = document.getElementById("ticketnos").value;
                const ticketAmount = <?php echo $amount; ?>;
                const totalAmount = ticketCount * ticketAmount;
                document.getElementById("totalAmountDisplay2").innerText = totalAmount.toFixed(2);
                document.getElementById("totalAmountDisplay1").innerText = totalAmount.toFixed(2);
            }

            function updateTotalcards() {
                const ticketCount = document.getElementById("ticketnos").value;
                const ticketAmount = <?php echo $amount; ?>;
                const totalAmount = ticketCount * ticketAmount;
                document.getElementById("totalAmountDisplay2").innerText = totalAmount.toFixed(2);
                document.getElementById("totalAmountDisplay1").innerText = totalAmount.toFixed(2);
            }
        </script>
    </main>

    <!-- FOOTER START -->
    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.php">Careers</a></li>
                    <li><a href="#">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="../html/faqs.html">FAQs</a></li>
                    <li><a href="../php/user-contacts.php">Help Center</a></li>
                    <li><a href="../php/user-contacts.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="../php/user_index.php">Home</a></li>
                    <li><a href="../php/user_events.php">Events</a></li>
                    <li><a href="../php/user_calendar.php">Calendar</a></li>
                    <li><a href="../php/user_aboutus.php">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SimEvents. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>

    <!-- FOOTER END -->
    <!-- JAVASCRIPT LINKS -->
    <script src="../assets/js/navbarandfooter.js"></script>
    <script src="../assets/js/payment-fill-up.js"></script>
</body>

</html>