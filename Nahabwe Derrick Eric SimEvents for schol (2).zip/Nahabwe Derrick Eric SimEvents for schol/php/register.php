<?php
require '../php/conn.php'; // Ensure the connection is valid

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fname = $_POST['firstname'];
    $lname = $_POST['lastname'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];

    // Check if passwords match
    if ($password !== $confirmpassword) {
        die("The two passwords don't match.");
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Correct SQL with 5 placeholders for 5 values
    $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, username, user_password) VALUES (?, ?, ?, ?, ?)");

    if (!$stmt) {
        die("Statement preparation failed: " . $conn->error);  // Handle preparation errors
    }

    // Bind parameters correctly (5 placeholders)
    $stmt->bind_param("sssss", $fname, $lname, $email, $username, $hashed_password);

    // Execute the query
    if ($stmt->execute()) {
        echo "Registration successful! Redirecting to login...";
        // Correct the redirect to include the .php extension
        header("Location: ../html/login-page.html"); // Redirect to the login page or any page you want
        exit(); // Stop further execution of the script
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "WRONG REQUEST METHOD";
}
