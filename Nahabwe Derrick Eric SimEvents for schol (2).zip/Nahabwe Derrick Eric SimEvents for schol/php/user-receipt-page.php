<?php

include 'conn.php';
session_start();


if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

$ticketID = isset($_GET['ticketID']) ? $_GET['ticketID'] : 'Unknown';
$eventID = isset($_GET['event_id']) ? $_GET['event_id'] : 'Unknown';
$eventName = isset($_GET['eventName']) ? $_GET['eventName'] : 'Unknown Event';
$amountPaid = isset($_GET['amountPaid']) ? $_GET['amountPaid'] : '0.00';
$fullName = isset($_GET['fullName']) ? $_GET['fullName'] : 'Guest';
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">

    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/user-receipt-page.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
    <title>Ticket Receipt</title>
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <p class="prof" onclick="proflogout()"><?php echo $_SESSION['username'] ?></p>
                <div class="log-out" id="profid">
                    <a href="./logout.php">
                        <p><i class="fas fa-sign-out-alt"></i> LogOut</p>
                    </a>
                </div>
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
    <div class="main-tag">
        <button><i class="fa-solid fa-arrow-up"></i> Go back</button>
        <div class="ticket-container">
            <div class="ticket-header">🎟️ Ticket Receipt</div>
            <div class="ticket-details">
                <p>Event: <strong><?php echo htmlspecialchars($eventName); ?></strong></p>
                <p>Ticket ID: <strong>#<?php echo htmlspecialchars($ticketID); ?></strong></p>
                <p>Full Name: <strong><?php echo htmlspecialchars($fullName); ?></strong></p>
                <p>Amount Paid: <strong>UGX <?php echo number_format($amountPaid, 2); ?></strong></p>
            </div>
            <div class="footer">Thank you for your purchase!</div>
        </div>
    </div>
    <?php include '../php/partials/footer.php' ?>
    <script src="../assets/js/navbarandfooter.js"></script>
</body>

</html>