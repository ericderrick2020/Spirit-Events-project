-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: event_logins
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_1_categories`
--

DROP TABLE IF EXISTS `event_1_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_1_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1_categories`
--

LOCK TABLES `event_1_categories` WRITE;
/*!40000 ALTER TABLE `event_1_categories` DISABLE KEYS */;
INSERT INTO `event_1_categories` VALUES (1,'ORDINARY',2000.00),(2,'VIP',50000.00),(3,'TABLE',100000.00);
/*!40000 ALTER TABLE `event_1_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1_tickets`
--

DROP TABLE IF EXISTS `event_1_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_1_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_1_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1_tickets`
--

LOCK TABLES `event_1_tickets` WRITE;
/*!40000 ALTER TABLE `event_1_tickets` DISABLE KEYS */;
INSERT INTO `event_1_tickets` VALUES (1,NULL,'6942',68000.00,NULL,NULL,'2024-11-19 05:51:38'),(2,NULL,'2015',2000.00,NULL,NULL,'2024-11-19 08:59:20'),(3,NULL,'9723',12000.00,NULL,NULL,'2024-11-19 09:50:28'),(4,NULL,'3746',300000.00,NULL,NULL,'2024-11-19 09:59:33'),(5,NULL,'2512',300000.00,NULL,NULL,'2024-11-19 09:59:51');
/*!40000 ALTER TABLE `event_1_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_2_categories`
--

DROP TABLE IF EXISTS `event_2_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_2_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_2_categories`
--

LOCK TABLES `event_2_categories` WRITE;
/*!40000 ALTER TABLE `event_2_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_2_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_2_tickets`
--

DROP TABLE IF EXISTS `event_2_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_2_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_2_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_2_tickets`
--

LOCK TABLES `event_2_tickets` WRITE;
/*!40000 ALTER TABLE `event_2_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_2_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_3_categories`
--

DROP TABLE IF EXISTS `event_3_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_3_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_3_categories`
--

LOCK TABLES `event_3_categories` WRITE;
/*!40000 ALTER TABLE `event_3_categories` DISABLE KEYS */;
INSERT INTO `event_3_categories` VALUES (1,'ORDINARY',150000.00),(2,'VIP',300000.00),(3,'SHAMPAIGHN',1000000.00);
/*!40000 ALTER TABLE `event_3_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_3_tickets`
--

DROP TABLE IF EXISTS `event_3_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_3_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_3_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_3_tickets`
--

LOCK TABLES `event_3_tickets` WRITE;
/*!40000 ALTER TABLE `event_3_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_3_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_4_categories`
--

DROP TABLE IF EXISTS `event_4_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_4_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_4_categories`
--

LOCK TABLES `event_4_categories` WRITE;
/*!40000 ALTER TABLE `event_4_categories` DISABLE KEYS */;
INSERT INTO `event_4_categories` VALUES (1,'ORDINARY',10000.00),(2,'VIP',30000.00),(3,'HIGH TABLE',500000.00);
/*!40000 ALTER TABLE `event_4_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_4_tickets`
--

DROP TABLE IF EXISTS `event_4_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_4_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_4_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_4_tickets`
--

LOCK TABLES `event_4_tickets` WRITE;
/*!40000 ALTER TABLE `event_4_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_4_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_5_categories`
--

DROP TABLE IF EXISTS `event_5_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_5_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_5_categories`
--

LOCK TABLES `event_5_categories` WRITE;
/*!40000 ALTER TABLE `event_5_categories` DISABLE KEYS */;
INSERT INTO `event_5_categories` VALUES (1,'ordinary',5000.00),(2,'VIP',70000.00);
/*!40000 ALTER TABLE `event_5_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_5_tickets`
--

DROP TABLE IF EXISTS `event_5_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_5_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_5_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_5_tickets`
--

LOCK TABLES `event_5_tickets` WRITE;
/*!40000 ALTER TABLE `event_5_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_5_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_6_categories`
--

DROP TABLE IF EXISTS `event_6_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_6_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_6_categories`
--

LOCK TABLES `event_6_categories` WRITE;
/*!40000 ALTER TABLE `event_6_categories` DISABLE KEYS */;
INSERT INTO `event_6_categories` VALUES (1,'Ticket',40000.00);
/*!40000 ALTER TABLE `event_6_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_6_tickets`
--

DROP TABLE IF EXISTS `event_6_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_6_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_6_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_6_tickets`
--

LOCK TABLES `event_6_tickets` WRITE;
/*!40000 ALTER TABLE `event_6_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_6_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_7_categories`
--

DROP TABLE IF EXISTS `event_7_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_7_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_7_categories`
--

LOCK TABLES `event_7_categories` WRITE;
/*!40000 ALTER TABLE `event_7_categories` DISABLE KEYS */;
INSERT INTO `event_7_categories` VALUES (1,'Popcorn, Soda, Chicken',120000.00);
/*!40000 ALTER TABLE `event_7_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_7_tickets`
--

DROP TABLE IF EXISTS `event_7_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_7_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_7_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_7_tickets`
--

LOCK TABLES `event_7_tickets` WRITE;
/*!40000 ALTER TABLE `event_7_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_7_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_8_categories`
--

DROP TABLE IF EXISTS `event_8_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_8_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_8_categories`
--

LOCK TABLES `event_8_categories` WRITE;
/*!40000 ALTER TABLE `event_8_categories` DISABLE KEYS */;
INSERT INTO `event_8_categories` VALUES (1,'VIP',34000.00);
/*!40000 ALTER TABLE `event_8_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_8_tickets`
--

DROP TABLE IF EXISTS `event_8_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_8_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_8_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_8_tickets`
--

LOCK TABLES `event_8_tickets` WRITE;
/*!40000 ALTER TABLE `event_8_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_8_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_crew`
--

DROP TABLE IF EXISTS `event_crew`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_crew` (
  `crew_Name` varchar(500) DEFAULT NULL,
  `crew_Leader` varchar(500) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `event_interest` varchar(500) NOT NULL,
  `crew_size` int DEFAULT NULL,
  `special_skills` varchar(900) DEFAULT NULL,
  PRIMARY KEY (`event_interest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_crew`
--

LOCK TABLES `event_crew` WRITE;
/*!40000 ALTER TABLE `event_crew` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_crew` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `event_id` int NOT NULL AUTO_INCREMENT,
  `event_images` varchar(900) DEFAULT NULL,
  `event_name` varchar(100) NOT NULL,
  `event_date` date DEFAULT NULL,
  `event_location` varchar(100) DEFAULT NULL,
  `event_category` varchar(400) DEFAULT NULL,
  `event_description` longtext,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `event_category` (`event_category`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'../assets/img/uploads/Landscape galaxy event music concert flyer template - Made with PosterMyWall.jpg','EVENT NAME','2024-11-02','Acacia Avenue',NULL,'\"*EVENT NAME* was an unforgettable experience from start to finish. From the moment I arrived, the atmosphere was electric, buzzing with excitement and anticipation. The venue was perfectly chosen, with plenty of space to mingle, engage, and immerse ourselves in everything the event had to offer. The attention to detail was evident in every corner—from the beautifully designed spaces to the thoughtful touches in the event layout.\r\n\r\nWhat really stood out was the incredible lineup of speakers and performers. Each session was insightful and inspiring, offering a perfect blend of expert knowledge and real-world application. Whether it was the thought-provoking keynote, the engaging workshops, or the dynamic panels, every segment seemed to offer something valuable.\r\n\r\nThe networking opportunities were also a highlight. I had the chance to connect with so many passionate individuals who share similar interests, and the conversations were both stimulating and meaningful. It\'s not every day you get to meet such a diverse group of people who are all so eager to learn, collaborate, and push boundaries.\r\n\r\nAnd let\'s not forget the entertainment and food—both were top-notch! From delicious local bites to fun activities that kept the mood light, everything was thoughtfully curated. Overall, *EVENT NAME* was an immersive, inspiring, and fun-filled experience that left me feeling motivated and excited for what’s next. If you ever get the chance to attend, don’t hesitate—it’s an event you won\'t want to miss!\"','2024-11-19 05:40:23','2024-11-19 05:40:23',NULL,NULL),(2,'../assets/img/uploads/image_3.jpg','Tropical Summer Party','2024-12-20','Entebbe Beach',NULL,'**Tropical Summer Party** – an unforgettable experience under the sun, filled with vibrant colors, tropical vibes, and the best summer beats! This event is all about embracing the carefree spirit of the season while enjoying good company, delicious drinks, and an unforgettable atmosphere. \r\n\r\n### Event Highlights:\r\n- **Tropical Drinks & Cocktails**: Sip on refreshing cocktails like piña coladas, mojitos, and tropical punches, served poolside or in a laid-back, island-style lounge.\r\n- **Beachwear Dress Code**: Whether you’re rocking Hawaiian shirts, floral dresses, or your favorite sunglasses, this is the time to flaunt your best summer attire.\r\n- **Live Music & DJs**: Dance the night away with the hottest tropical beats, reggae, calypso, and island-inspired tunes from live bands and top DJs.\r\n- **Themed Decor**: Think palm trees, tiki torches, colorful leis, and sandy vibes—turning the venue into a tropical paradise. \r\n- **Games & Fun Activities**: From limbo contests and beach volleyball to coconut bowling, there’s no shortage of fun activities to keep you entertained all day.\r\n- **Tropical Cuisine**: Indulge in a feast of tropical delicacies, from grilled seafood and island BBQ to fresh fruit platters, ceviche, and tropical-inspired desserts.\r\n\r\n### Why You Should Attend:\r\n- **Relaxed Vibes**: It’s the perfect chance to unwind and enjoy the warm weather with friends or meet new people who share your love of summer fun.\r\n- **Instagram-Worthy Moments**: From the stunning beach backdrop to the vibrant décor, there will be plenty of picturesque moments to capture.\r\n- **A Taste of the Tropics**: Whether you’re enjoying exotic drinks, island snacks, or soaking in the sunny vibes, this event brings the essence of the tropics to life.\r\n\r\nGet ready to celebrate the season in style at the *Tropical Summer Party*—the ultimate escape to a tropical paradise! ??☀️','2024-11-19 05:44:04','2024-11-19 05:44:04','10:45:00','21:48:00'),(3,'../assets/img/uploads/image_4.jpg','Chromakopia','2024-09-06','Hollywood',NULL,'Log in\r\n\r\nSign up\r\nYou said:\r\ncreate a random comment about \"EVENT NAME\"\r\nChatGPT said:\r\nChatGPT\r\n\"Just attended EVENT NAME and wow, what an experience! The energy was off the charts, and I loved how everything came together seamlessly. Can’t wait for the next one!\"\r\n\r\n\r\n\r\nYou said:\r\na long description\r\nChatGPT said:\r\nChatGPT\r\n\"EVENT NAME was an unforgettable experience from start to finish. From the moment I arrived, the atmosphere was electric, buzzing with excitement and anticipation. The venue was perfectly chosen, with plenty of space to mingle, engage, and immerse ourselves in everything the event had to offer. The attention to detail was evident in every corner—from the beautifully designed spaces to the thoughtful touches in the event layout.\r\n\r\nWhat really stood out was the incredible lineup of speakers and performers. Each session was insightful and inspiring, offering a perfect blend of expert knowledge and real-world application. Whether it was the thought-provoking keynote, the engaging workshops, or the dynamic panels, every segment seemed to offer something valuable.\r\n\r\nThe networking opportunities were also a highlight. I had the chance to connect with so many passionate individuals who share similar interests, and the conversations were both stimulating and meaningful. It\'s not every day you get to meet such a diverse group of people who are all so eager to learn, collaborate, and push boundaries.\r\n\r\nAnd let\'s not forget the entertainment and food—both were top-notch! From delicious local bites to fun activities that kept the mood light, everything was thoughtfully curated. Overall, EVENT NAME was an immersive, inspiring, and fun-filled experience that left me feeling motivated and excited for what’s next. If you ever get the chance to attend, don’t hesitate—it’s an event you won\'t want to miss!\"\r\n\r\n\r\n\r\nYou said:\r\nwhy isnt the time appearing <?php\r\n// Include the database connection file\r\nrequire \'../php/conn.php\';\r\nsession_start();\r\n\r\n// Check if the request method is POST\r\nif ($_SERVER[\'REQUEST_METHOD\'] == \'POST\') {\r\n    // Collecting data from the form\r\n    $eventname = $_POST[\'event-name\'];\r\n    $eventdate = $_POST[\'date\'];\r\n    $event_location = $_POST[\'Location-name\'];\r\n    $event_description = $_POST[\'describe\'];\r\n    $start_time = $_POST[\'start_time\'];\r\n    $end_time = $_POST[\'end_time\'];\r\n    $venueCosts = $_POST[\'venueCost\'] ?? [];\r\n    $venueCategories = $_POST[\'venueCategory\'] ?? [];\r\n\r\n    // Handle image upload\r\n    if (isset($_FILES[\'image\']) && $_FILES[\'image\'][\'error\'] == UPLOAD_ERR_OK) {\r\n        $targetDir = \"../assets/img/uploads/\";\r\n        $targetFile = $targetDir . basename($_FILES[\'image\'][\'name\']);\r\n\r\n        if (move_uploaded_file($_FILES[\'image\'][\'tmp_name\'], $targetFile)) {\r\n            // Insert the event into the events table\r\n            $stmt = $conn->prepare(\r\n                \"INSERT INTO events (event_images, event_name, event_date, event_location, event_description, start_time, end_time) \r\n                 VALUES (?, ?, ?, ?, ?, ?, ?)\"\r\n            );\r\n            $stmt->bind_param(\"sssssss\", $targetFile, $eventname, $eventdate, $event_location, $event_description, $start_time, $end_time);\r\n\r\n            if ($stmt->execute()) {\r\n                $eventId = $conn->insert_id;  // Get the last inserted event ID\r\n\r\n                // Create a new table for this event\'s categories\r\n                $newTableName = \"event_{$eventId}_categories\";\r\n                $createTableQuery = \"\r\n                    CREATE TABLE $newTableName (\r\n                        id INT AUTO_INCREMENT PRIMARY KEY,\r\n                        category_name VARCHAR(255),\r\n                        cost DECIMAL(10,2)\r\n                    )\r\n                \";\r\n\r\n                if ($conn->query($createTableQuery) === TRUE) {\r\n                    // Insert categories into the new table\r\n                    $insertQuery = \"INSERT INTO $newTableName (category_name, cost) VALUES (?, ?)\";\r\n                    $categoryStmt = $conn->prepare($insertQuery);\r\n\r\n                    foreach ($venueCategories as $index => $venueCategory) {\r\n                        $venueCost = $venueCosts[$index] ?? 0;\r\n                        $categoryStmt->bind_param(\"sd\", $venueCategory, $venueCost);\r\n                        if (!$categoryStmt->execute()) {\r\n                            echo \"Error adding category: \" . $categoryStmt->error;\r\n                        }\r\n                    }\r\n\r\n                    // Create a separate ticket table for the event\r\n                    $ticketTableName = \"event_{$eventId}_tickets\";\r\n                    $createTicketTableQuery = \"\r\n                        CREATE TABLE $ticketTableName (\r\n                            id INT AUTO_INCREMENT PRIMARY KEY,\r\n                            user_id INT,\r\n                            ticket_id VARCHAR(255),\r\n                            amount DECIMAL(10,2),\r\n                            payment_method VARCHAR(50),\r\n                            qr_code VARCHAR(255),\r\n                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\r\n                            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE\r\n                        )\r\n                    \";\r\n\r\n                    if ($conn->query($createTicketTableQuery) === TRUE) {\r\n                        // Ticket table created successfully\r\n                        header(\"Location: ./dashboard_event.php\");\r\n                        exit();\r\n                    } else {\r\n                        echo \"Error creating ticket table: \" . $conn->error;\r\n                    }\r\n\r\n                    $categoryStmt->close();\r\n                } else {\r\n                    echo \"Error creating categories table: \" . $conn->error;\r\n                }\r\n            } else {\r\n                echo \"Error adding event: \" . $stmt->error;\r\n            }\r\n\r\n            $stmt->close();\r\n        } else {\r\n            echo \"Error moving uploaded file.\";\r\n        }\r\n    } else {\r\n        echo \"Error uploading image.\";\r\n    }\r\n}\r\n?>\r\nChatGPT said:\r\nChatGPT\r\nIt looks like your code is handling the insertion of event data, including start and end times, but you\'re facing an issue where the time is not appearing as expected. There are a few potential reasons why the start_time and end_time values may not be showing up correctly. Here are some things to check:\r\n\r\n1. Check HTML Form Input Names\r\nEnsure that the names of your form fields for start_time and end_time match exactly with what you\'re using in the PHP script. The HTML form fields should look something like this:\r\n\r\nhtml\r\nCopy code\r\n<input type=\"time\" name=\"start_time\" required>\r\n<input type=\"time\" name=\"end_time\" required>\r\nThese name attributes (start_time and end_time) should match the names you\'re using in your PHP code ($_POST[\'start_time\'] and $_POST[\'end_time\']).\r\n\r\n2. Check Time Format\r\nThe time input type in HTML only allows for values in the HH:MM format (e.g., 14:30). If you\'re inserting the values into a MySQL database, ensure that the start_time and end_time columns in your database are using the correct data type.\r\n\r\nFor MySQL, the TIME data type should be used for storing time values. Your SQL table should have start_time and end_time columns defined as TIME. Example:\r\n\r\nsql\r\nCopy code\r\nCREATE TABLE events (\r\n    id INT AUTO_INCREMENT PRIMARY KEY,\r\n    event_name VARCHAR(255),\r\n    event_date DATE,\r\n    event_location VARCHAR(255),\r\n    event_description TEXT,\r\n    start_time TIME,\r\n    end_time TIME\r\n);\r\n3. Check for Missing or Incorrect Data\r\nMake sure that the $_POST[\'start_time\'] and $_POST[\'end_time\'] values are being correctly passed to the PHP script. You can do this by adding some debugging code right before your database insert to check what data is being received:\r\n\r\nphp\r\nCopy code\r\nvar_dump($_POST[\'start_time\']);\r\nvar_dump($_POST[\'end_time\']);\r\nThis will print the values of start_time and end_time to the screen, which helps you determine if the data is coming through correctly from the form.\r\n\r\n4. Ensure Data Is Being Inserted Correctly\r\nIf the form data is coming through correctly but not showing up in the database, the issue might be with the SQL insert or binding of parameters. In your prepared statement:\r\n\r\nphp\r\nCopy code\r\n$stmt->bind_param(\"sssssss\", $targetFile, $eventname, $eventdate, $event_location, $event_description, $start_time, $end_time);\r\nMake sure the data types being bound to the parameters match the expected data types in the database. For start_time and end_time, they should be treated as strings in the bind_param method, so you are correct to bind them as s (strings). However, double-check that $start_time and $end_time are not null or empty strings when passed into the prepared statement.\r\n\r\n5. Verify the Column Type in Database\r\nEnsure that the database column types for start_time and end_time are correctly defined as TIME. If the columns are defined with the wrong data type (like VARCHAR), it may not store the time values properly.\r\n\r\n6. Debugging the SQL Query\r\nIf you\'re still having issues, you can also log or print the SQL query itself to see if there\'s an issue with how it\'s being executed:\r\n\r\nphp\r\nCopy code\r\n$sql = \"INSERT INTO events (event_images, event_name, event_date, event_location, event_description, start_time, end_time) \r\n        VALUES (?, ?, ?, ?, ?, ?, ?)\";\r\necho $sql;  // Output the query for debugging\r\nIf you find any errors in the query, they will likely point you toward the issue.\r\n\r\n7. Check for Errors\r\nIf you’re using MySQLi or PDO, you should always check for errors when executing your queries. After executing the query, check if $stmt->execute() returns false, and if so, use $stmt->error to find out more about what went wrong.\r\n\r\nFor example:\r\n\r\nphp\r\nCopy code\r\nif ($stmt->execute()) {\r\n    echo \"Event added successfully.\";\r\n} else {\r\n    echo \"Error executing query: \" . $stmt->error;\r\n}\r\nBy following these debugging steps, you should be able to pinpoint why the time is not appearing as expected in your database or frontend.\r\n\r\n\r\n\r\nYou said:\r\nTropical Summer Party\r\nChatGPT said:\r\nChatGPT\r\nTropical Summer Party – an unforgettable experience under the sun, filled with vibrant colors, tropical vibes, and the best summer beats! This event is all about embracing the carefree spirit of the season while enjoying good company, delicious drinks, and an unforgettable atmosphere.\r\n\r\nEvent Highlights:\r\nTropical Drinks & Cocktails: Sip on refreshing cocktails like piña coladas, mojitos, and tropical punches, served poolside or in a laid-back, island-style lounge.\r\nBeachwear Dress Code: Whether you’re rocking Hawaiian shirts, floral dresses, or your favorite sunglasses, this is the time to flaunt your best summer attire.\r\nLive Music & DJs: Dance the night away with the hottest tropical beats, reggae, calypso, and island-inspired tunes from live bands and top DJs.\r\nThemed Decor: Think palm trees, tiki torches, colorful leis, and sandy vibes—turning the venue into a tropical paradise.\r\nGames & Fun Activities: From limbo contests and beach volleyball to coconut bowling, there’s no shortage of fun activities to keep you entertained all day.\r\nTropical Cuisine: Indulge in a feast of tropical delicacies, from grilled seafood and island BBQ to fresh fruit platters, ceviche, and tropical-inspired desserts.\r\nWhy You Should Attend:\r\nRelaxed Vibes: It’s the perfect chance to unwind and enjoy the warm weather with friends or meet new people who share your love of summer fun.\r\nInstagram-Worthy Moments: From the stunning beach backdrop to the vibrant décor, there will be plenty of picturesque moments to capture.\r\nA Taste of the Tropics: Whether you’re enjoying exotic drinks, island snacks, or soaking in the sunny vibes, this event brings the essence of the tropics to life.\r\nGet ready to celebrate the season in style at the Tropical Summer Party—the ultimate escape to a tropical paradise! ??☀️\r\n\r\n\r\n\r\nYou said:\r\nCHROMAKOPIA\r\nChatGPT said:\r\nChatGPT\r\nCHROMAKOPIA – A Vibrant Celebration of Color, Art, and Imagination!\r\n\r\nStep into a world where color is the key to unlocking creativity, innovation, and self-expression. CHROMAKOPIA is not just an event; it\'s a sensory experience that brings together the magic of color, the beauty of art, and the thrill of collaboration. Whether you\'re an art enthusiast, a creator, or someone looking for an inspiring environment, CHROMAKOPIA is the ultimate celebration of all things colorful and artistic.\r\n\r\nEvent Highlights:\r\nInteractive Art Installations: Immerse yourself in larger-than-life art displays where you become part of the artwork! Think vibrant murals, multi-dimensional sculptures, and interactive exhibits that invite you to engage with color in new and exciting ways.\r\n\r\nColor Workshops & Live Demos: Watch as artists bring their canvases to life in real-time. From watercolor techniques to digital art innovations, there’s a hands-on workshop for everyone. Learn how to mix colors, explore different mediums, or even create your own masterpiece!\r\n\r\nThe Chromatic Fashion Show: A runway showcase featuring the brightest and boldest color-inspired designs from emerging fashion designers. Experience the fusion of art and fashion as models strut down the runway in striking, color-themed ensembles.\r\n\r\nLive Music & Performances: Enjoy live performances from musicians and performers whose works explore the world of color through sound and visual elements. Expect experimental sounds, colorful lighting, and a fusion of art forms.\r\n\r\nFood & Drink Experience: Indulge in a feast for the senses with food and beverages that match the vibrancy of the event. Colorful cocktails, rainbow pastries, and artistic food presentations will surprise and delight your taste buds.\r\n\r\nColorful Marketplace: Shop unique, locally made, and one-of-a-kind items from artists, creators, and vendors who specialize in colorful works of art, handmade crafts, vibrant clothing, and much more.\r\n\r\nWhy You Should Attend:\r\nAn Explosion of Creativity: If you’re a lover of art, design, and color, CHROMAKOPIA will inspire and ignite your creative spirit like never before.\r\n\r\nExclusive Art Installations: This is the perfect event for anyone looking to explore new forms of interactive and contemporary art that blur the lines between artist and audience.\r\n\r\nConnect with Creatives: Network with artists, designers, musicians, and creators who share your passion for color and creativity. Whether you\'re looking to collaborate or simply enjoy like-minded company, the connections made here are bound to be unforgettable.\r\n\r\nColor Your World: Whether you\'re walking through a sea of painted walls, sipping a neon-colored drink, or wearing your brightest outfit, CHROMAKOPIA will leave you feeling inspired and full of creative energy.\r\n\r\nSocial Media Magic: If you love posting Instagram-worthy moments, this event is a dream come true. From stunning installations to neon-lit corners, CHROMAKOPIA offers endless opportunities for vibrant photo ops.\r\n\r\nDon\'t Miss Out!\r\nBring your most colorful self and dive into a world where art, culture, and color collide in the most exciting way possible. Whether you\'re here to get inspired, learn, shop, or simply have fun, CHROMAKOPIA is sure to be an event that will spark your imagination and leave a lasting impression.\r\n\r\nJoin us and let the colors of CHROMAKOPIA ignite your creativity! ??✨','2024-11-19 05:50:49','2024-11-19 05:50:49','05:50:00','23:49:00'),(4,'../assets/img/uploads/thanksgiving-celebrate-party-poster-landscape-design-template-2fba86646ccab5ce674d0532afe1a867_screen.jpg','Thanks Giving','2024-11-27','Kawempe',NULL,'**Thanksgiving** – A Heartwarming Celebration of Gratitude, Family, and Tradition\r\n\r\nThanksgiving is more than just a holiday; it’s a time to gather with loved ones, reflect on the blessings of the past year, and celebrate the joy of togetherness. Whether you\'re enjoying a big family feast, giving back to the community, or simply taking a moment to appreciate the good things in life, Thanksgiving is a special occasion that brings warmth, kindness, and appreciation into our hearts.\r\n\r\n### Event Highlights:\r\n- **A Feast to Remember**: The centerpiece of Thanksgiving is the meal—an extravagant spread of comfort food that’s as much about tradition as it is about flavor. Roasted turkey, mashed potatoes, stuffing, cranberry sauce, gravy, green beans, pumpkin pie, and more. The table is set with a variety of dishes that everyone looks forward to year after year.\r\n  \r\n- **Gratitude Moments**: Thanksgiving is a time to pause and reflect. Whether it’s going around the dinner table sharing what you\'re thankful for, writing down gratitude notes, or even volunteering to help those less fortunate, this is a holiday that reminds us of the importance of being thankful and giving back.\r\n\r\n- **Quality Time with Family & Friends**: This is a time to reconnect with the people who matter most—whether they\'re near or far. Spending time with family, friends, or even new faces you meet at community events, Thanksgiving fosters a sense of belonging and love.\r\n\r\n- **Football & Festivities**: For many, Thanksgiving isn’t complete without watching a football game. Whether it’s a local game or the big NFL matchups, the excitement of the game often adds to the festive atmosphere. You can also enjoy parades, family games, or post-dinner walks to get everyone moving.\r\n\r\n- **Pumpkin & Pecan Pie**: Thanksgiving is the season of pies, and pumpkin and pecan are two of the most beloved options. After the big meal, there’s nothing quite like enjoying a slice of homemade pie with whipped cream or a scoop of vanilla ice cream.\r\n\r\n### Why You Should Celebrate:\r\n- **Embrace the Spirit of Gratitude**: Thanksgiving is all about appreciating what we have and acknowledging the people and moments that make our lives meaningful. It’s an opportunity to slow down, count our blessings, and find joy in the simple things.\r\n\r\n- **A Time to Give Back**: Many people choose to volunteer or donate during Thanksgiving, whether it’s helping serve a meal at a shelter, donating food to those in need, or contributing to charity drives. Giving back is an integral part of the holiday spirit.\r\n\r\n- **Create New Traditions**: While Thanksgiving is steeped in tradition, it’s also a time to create new memories. Whether it’s cooking a new dish together, starting a fun family game, or sharing a heartfelt tradition, this holiday offers countless opportunities to make lasting memories with those you love.\r\n\r\n- **Warmth and Togetherness**: Thanksgiving reminds us of the power of community. The laughter, the stories, the memories made around the dinner table—these are what make Thanksgiving special. Whether it’s your first celebration or your 50th, it’s always about coming together and cherishing each other’s company.\r\n\r\n### Celebrating Thanksgiving:\r\n- **Host a Thanksgiving Feast**: Gather your family and friends around the table for a festive meal. Decorate your home with fall colors—think rich oranges, reds, and golds—and create a cozy, welcoming atmosphere.\r\n  \r\n- **Volunteer & Share the Love**: Consider giving back by helping others who may not have the same opportunities for celebration. Volunteering at a food bank, serving at a shelter, or donating to a cause that’s close to your heart can be a meaningful way to spread kindness during the holiday.\r\n\r\n- **Reflect and Reconnect**: Take time to reflect on what you’re thankful for this year, and make space for meaningful connections. Thanksgiving is a great time to reconnect with family members, friends, and even colleagues you may not see as often.\r\n\r\n- **Enjoy the Little Things**: Whether it’s the first bite of mashed potatoes, the warmth of a crackling fire, or the joy of sharing a laugh with loved ones, Thanksgiving reminds us to savor the little moments.\r\n\r\n### Conclusion:\r\nThanksgiving is a time for reflection, appreciation, and celebration. It\'s about coming together, making memories, and sharing the joy of being alive. Whether it\'s through family dinners, community involvement, or quiet moments of gratitude, this holiday is a reminder of the importance of love, kindness, and connection. This Thanksgiving, take a moment to appreciate everything that makes your life special—and share that appreciation with the people who matter most. \r\n\r\nHappy Thanksgiving! ???','2024-11-19 05:58:10','2024-11-19 05:58:10','08:56:00','21:56:00'),(5,'../assets/img/uploads/good-friday-worship-service-post-template-design-a9beb6d39c967fe123e4589df08397a3_screen.jpg','Good Friday Worship Service','2024-04-15','Lugogo Cricket Oval',NULL,'**Good Friday** – A Day of Reflection, Reverence, and Remembrance\r\n\r\nGood Friday is one of the most solemn and significant days in the Christian calendar. It marks the crucifixion of Jesus Christ and His ultimate sacrifice for humanity. It is a day to reflect on the depth of God\'s love, the meaning of Christ’s suffering, and the promise of redemption that His death brings to the world.\r\n\r\n### The Meaning of Good Friday:\r\n- **A Day of Sacrifice**: Good Friday commemorates the day when Jesus was crucified, offering Himself as the ultimate sacrifice for the sins of humanity. This selfless act of love and atonement is central to the Christian faith and serves as a reminder of the power of grace, forgiveness, and redemption.\r\n  \r\n- **Reflection and Repentance**: For Christians, Good Friday is a time for solemn reflection, meditation, and repentance. It’s a day to pause and contemplate the suffering and death of Christ, understanding the depth of His sacrifice. It is also an opportunity for believers to examine their own lives, seek forgiveness for their sins, and grow spiritually.\r\n\r\n- **The Passion of Christ**: On Good Friday, the \"Passion\" of Christ—His suffering, trial, and death—is often read or recounted in Christian services. The Passion story invites worshippers to walk through the painful journey Jesus endured, from His arrest to His final breath on the cross. This helps deepen their understanding of the significance of His sacrifice.\r\n\r\n### Traditions and Observances:\r\n- **Church Services**: Many Christian communities observe Good Friday with special services that include scripture readings, hymns, and prayer. These services often feature a reading from the Gospel, recounting the events of Christ\'s final hours, followed by a time of reflection and prayer.\r\n\r\n- **The Stations of the Cross**: In some Christian traditions, particularly in the Catholic and Anglican faiths, Good Friday is marked by the \"Stations of the Cross.\" This ritual involves a series of 14 artistic representations that depict the events of Christ’s crucifixion, starting from His condemnation to the final moments of His death. Participants walk through these stations, reflecting on each moment as they go.\r\n\r\n- **Fasting and Penitence**: Many Christians fast or engage in acts of penitence on Good Friday. The day is often observed in a spirit of humility and quiet contemplation, where believers may choose to forgo certain comforts or pleasures in recognition of the solemnity of the occasion.\r\n\r\n- **The Three Hours\' Agony**: Some traditions hold a special service that lasts for three hours, reflecting the three hours Christ hung on the cross. During this time, churchgoers may engage in silent prayer, song, and reflection, deeply meditating on Christ’s suffering and His words from the cross.\r\n\r\n- **The Good Friday Cross**: In some Christian communities, a cross may be prominently displayed in the church, draped in black cloth or with a crown of thorns placed upon it, symbolizing the sacrifice of Christ. Some also engage in a \"Veneration of the Cross,\" where worshippers may kneel before the cross in reverence and gratitude.\r\n\r\n### Why Good Friday is Important:\r\n- **A Day of Gratitude**: Good Friday is a day that calls Christians to reflect on the immense love and sacrifice Jesus demonstrated by laying down His life. It is a moment to be thankful for the gift of salvation through His death, which Christians believe paved the way for eternal life and reconciliation with God.\r\n\r\n- **Understanding the Cost of Grace**: The death of Jesus on the cross is a powerful reminder of the price that was paid for humanity\'s sins. Good Friday invites believers to consider the gravity of sin and the immeasurable grace offered through Christ\'s sacrifice.\r\n\r\n- **Preparation for Easter**: Good Friday, while solemn, also sets the stage for the joyful celebration of Easter. It is the precursor to the resurrection, when Christians believe Jesus triumphed over death, offering hope and victory over sin. In this way, Good Friday is not just a day of mourning but a day that points forward to the hope and promise of Easter Sunday.\r\n\r\n### How You Can Observe Good Friday:\r\n- **Attend a Service**: Participate in a Good Friday service at your local church. Many churches hold special liturgies, readings, and communion services to honor the significance of the day.\r\n  \r\n- **Reflect and Pray**: Take time to reflect on the meaning of Christ\'s sacrifice. Spend time in prayer, seeking forgiveness for your sins and expressing gratitude for the grace that Christ\'s death offers to all believers.\r\n\r\n- **Read Scripture**: Read the accounts of Christ’s crucifixion from the Gospels (Matthew 27, Mark 15, Luke 23, and John 19). Meditate on these passages and allow them to deepen your understanding of Christ’s suffering.\r\n\r\n- **Fast or Practice Silence**: Some people fast or refrain from certain activities as an act of penitence. Others may choose to spend the day in quiet contemplation, keeping the focus on the solemnity of the day.\r\n\r\n- **Volunteer or Serve Others**: Emulate Christ’s love and sacrifice by giving of yourself to others, especially those in need. Whether through acts of charity, volunteering, or helping those who are less fortunate, Good Friday is an opportunity to reflect Christ’s love through action.\r\n\r\n### Conclusion:\r\nGood Friday is a deeply meaningful day of reflection, reverence, and remembrance. It is a day to pause and consider the profound sacrifice made by Jesus Christ for the salvation of humanity. Through prayer, reflection, and acts of service, Christians honor the sacrifice that transformed the world and continue to live in the hope that His death on the cross offers to all people. \r\n\r\nAs you observe Good Friday, remember that while the day is somber, it is also full of hope, as it points to the resurrection and the new life that follows.','2024-11-19 06:05:09','2024-11-19 06:05:09','09:03:00','21:03:00'),(6,'../assets/img/uploads/images_1.jpg','The style friday Lockdown','2024-11-22','Giga Club',NULL,'**The Style Friday Lockdown** – A Chic, Cozy, and Fashion-Forward Weekend Vibe\r\n\r\nWhen the weekend rolls around and the world slows down, what better way to kick it off than with *The Style Friday Lockdown*? It’s the perfect blend of relaxed comfort and high-fashion vibes, making sure you’re both cozy at home and effortlessly chic. Whether you\'re embracing the lockdown at home or just taking a moment to unwind, this trend is all about embracing style with ease—because why sacrifice comfort for fashion when you can have both?\r\n\r\n### Event Highlights:\r\n- **Lounge-In Luxe**: Picture this: It\'s Friday evening, the work week is over, and you\'re settling into your living room or bedroom for a much-needed retreat. The *Style Friday Lockdown* is all about elevated loungewear. Think silk pajamas, oversized sweaters, matching sets, and plush slippers—because comfort never goes out of style. \r\n\r\n- **Cozy Yet Cool Outfits**: Whether you’re having a quiet night with friends on Zoom, binging your favorite series, or relaxing with a book, it’s time to look chic without the effort. Loungewear sets, oversized blazers, chic hoodies, and laid-back denim become your go-to staples. Even a simple pair of joggers can be dressed up with the right accessories—gold hoop earrings, sleek sneakers, or a statement scarf.\r\n\r\n- **Home-Spa Vibes**: A lockdown weekend is the perfect time for self-care, so why not turn your home into your own personal spa? Face masks, scented candles, essential oils, and a warm bubble bath are all part of the *Style Friday Lockdown* agenda. Add in some chic bathrobes and stylish slippers, and you’ve got the ultimate cozy, yet luxurious, home experience.\r\n\r\n- **Instagram-Worthy Setups**: What’s a stylish lockdown weekend without a little *grammable content*? Transform your living room or bedroom into an aesthetic wonderland. Think cozy throws, neatly arranged pillows, and mood lighting. Set up your Friday night retreat with coffee tables stacked with your favorite books, chic decor pieces, and, of course, your favorite beverage in a trendy mug or glass.\r\n\r\n- **Fashionable Virtual Hangouts**: Just because you’re spending the night in doesn’t mean you can’t look good! Host a virtual happy hour, game night, or dinner date with friends or loved ones, all while keeping it stylish in a relaxed, at-home outfit. Pair a slouchy sweater with a bold necklace or layered rings, and you’ll look effortlessly fashionable on screen.\r\n\r\n- **Caffeine & Cocktails**: Start your *Style Friday Lockdown* with a cup of artisan coffee, herbal tea, or even a freshly pressed juice in the morning, and switch it up with a signature cocktail in the evening. Think floral-inspired gin drinks, wine spritzers, or even a cozy spiked hot chocolate. A chic drink to accompany your evening vibe completes the look.\r\n\r\n- **Stylish Entertainment**: Whether you\'re catching up on the latest Netflix binge, watching a live-streamed concert, or diving into a good book, make the evening even more enjoyable by setting the scene. Cozy blankets, ambient lighting, and a playlist of mellow tunes or your favorite hits set the mood for a laid-back, stylish weekend.\r\n\r\n### Why You’ll Love It:\r\n- **Effortless Fashion**: The *Style Friday Lockdown* embraces the idea that staying stylish doesn’t have to be complicated. You can pull off elevated casual looks that make you feel chic while maintaining the comfort of staying in. Whether you’re into minimalist neutrals or bold prints, you can create looks that feel as good as they look.\r\n\r\n- **Mental & Physical Reset**: After a busy week, the *Friday Lockdown* provides the perfect opportunity to reset—mentally, physically, and emotionally. It’s a chance to recharge while still feeling put-together, whether you’re watching a movie or journaling your thoughts. Self-care never looked so good.\r\n\r\n- **Flexibility & Comfort**: The lockdown style is all about versatility. Comfort is key, but that doesn’t mean you can’t still make a statement. Mix and match cozy pieces with stylish accessories, and you’ll always look and feel ready to take on whatever the weekend brings.\r\n\r\n- **Connecting from a Distance**: Whether you\'re socially distancing or simply preferring a quiet night in, the *Style Friday Lockdown* lets you connect with friends and family without sacrificing your weekend style. You can still host virtual gatherings and be fashion-forward, all from the comfort of your home.\r\n\r\n### How to Make the Most of Your *Style Friday Lockdown*:\r\n- **Create Your Perfect Mood**: Set up your space for maximum comfort and style. Think soft lighting (string lights or candles), a cozy corner, or a chic coffee table setup.\r\n  \r\n- **Indulge in Comfort**: Choose soft, stylish fabrics—think cotton, silk, cashmere, or fleece. A warm hoodie, oversized knit, or silk sleepwear set can easily transition from lounging to a casual video call.\r\n\r\n- **Fashionable Face Masks**: If you\'re heading out to run errands or picking up takeout, why not make your mask part of your outfit? There are plenty of stylish, printed, or embroidered masks to keep your look on point while staying safe.\r\n\r\n- **Put Together a Lockdown Playlist**: Create a playlist that fits the mood—whether it\'s a relaxing mix of lo-fi beats, soulful jazz, or upbeat tunes to keep you energized. Music adds an extra layer of atmosphere to your lockdown retreat.\r\n\r\n- **Treat Yourself to a Little Extra**: Why not indulge in a nice bottle of wine, or grab a new book or movie that’s been on your list? A small treat like your favorite dessert or a fresh bouquet of flowers can elevate the whole vibe.\r\n\r\n### Conclusion:\r\nThe *Style Friday Lockdown* is the perfect fusion of comfort and chic, turning your weekend into a celebration of relaxation, style, and self-care. It’s all about embracing the weekend with a laid-back yet fashionable attitude—where comfort and style meet seamlessly. So, next time Friday rolls around, take the opportunity to slip into something comfortable, light the candles, pour yourself a drink, and enjoy the freedom of a cozy, stylish weekend in.','2024-11-19 06:17:49','2024-11-19 06:17:49','02:18:00','03:20:00'),(7,'../assets/img/uploads/hq720.jpg','Taker Cover Ofiicial Trailer Release','2024-11-13','Cinemax Entebbe',NULL,'**Taker Cover - Official Trailer Release** ?\r\n\r\nGet ready for the *official trailer release* of *Taker Cover*—the high-octane, edge-of-your-seat action thriller that\'s sure to leave you breathless! This is the moment fans have been eagerly waiting for, as the trailer drops, offering a sneak peek into the intense, action-packed world of *Taker Cover*. \r\n\r\n### About the Movie:\r\n*Taker Cover* follows a skilled, highly trained operative who is forced to confront the shadows of his past when a dangerous mission goes awry. With a mysterious organization pulling the strings, he’s caught in a deadly game of cat and mouse, forced to outwit his enemies while unraveling a web of deceit and betrayal. As the stakes get higher and the danger intensifies, trust becomes the most deadly weapon of all.\r\n\r\n### Trailer Highlights:\r\n- **Explosive Action Sequences**: From heart-stopping car chases to intense hand-to-hand combat, *Taker Cover* promises to deliver high-energy action scenes that will keep you on the edge of your seat. Expect jaw-dropping stunts, pulse-pounding explosions, and jaw-clenching moments.\r\n  \r\n- **Twists and Turns**: Just when you think you have the story figured out, the trailer teases unexpected plot twists that will have you guessing until the very end. Who can you trust? Who’s really behind the mission gone wrong? *Taker Cover* will keep you hooked with its suspenseful, unpredictable narrative.\r\n\r\n- **Star-Studded Cast**: Featuring an ensemble of A-list talent, the movie brings together some of the most charismatic actors in Hollywood today. Their performances promise to deliver layers of intrigue, emotion, and intensity, creating memorable characters that will stay with you long after the credits roll.\r\n\r\n- **Cinematic Visuals**: The trailer offers a glimpse into the stunning cinematography of *Taker Cover*, from breathtaking cityscapes to gritty, shadowy locations. The atmosphere is tense and immersive, enhancing the movie\'s intense, dramatic tone.\r\n\r\n- **Powerful Soundtrack**: The trailer’s music sets the perfect tone for the action, with a dynamic score that matches the movie’s pulse-pounding pace. The soundtrack elevates the tension, bringing every chase, fight, and reveal to life in a way that leaves you eager for more.\r\n\r\n### Why You Should Be Excited:\r\n- **Action Junkies Rejoice**: If you love high-stakes thrillers, *Taker Cover* is the movie you’ve been waiting for. With its combination of sleek choreography, strategic combat, and adrenaline-fueled pacing, this is one action film that will deliver on every level.\r\n  \r\n- **A Gripping Story**: Beyond the action, *Taker Cover* promises a gripping narrative that explores trust, betrayal, and redemption. The complex characters and emotional depth will keep you invested in the journey from start to finish.\r\n\r\n- **Edge-of-Your-Seat Suspense**: Whether you’re into mystery, espionage, or pure action thrills, this movie is bound to pull you in and keep you glued to your seat. The trailer alone hints at a story filled with twists, turns, and shocking reveals.\r\n\r\n### What’s Next?\r\nWith the trailer now live, fans around the world can finally get a taste of the excitement that *Taker Cover* brings. Stay tuned for more updates, including exclusive behind-the-scenes footage, cast interviews, and sneak peeks leading up to the film’s official release.\r\n\r\n**Don\'t miss out** on the action—watch the *Taker Cover* official trailer now, and mark your calendars for the highly anticipated release. This is one movie event you won\'t want to miss! ??\r\n\r\n**#TakerCover #OfficialTrailer #ActionThriller #MovieRelease #AdrenalineRush #BlockbusterFilm**\r\n','2024-11-19 06:24:49','2024-11-19 06:24:49','10:21:00','21:25:00'),(8,'../assets/img/uploads/images_2.jpg','Tyler Concert','2024-11-14','Bahai Temple',NULL,'**Tyler Concert – A Night of Unforgettable Energy and Vibes!** ??\r\n\r\nGet ready for an electrifying experience at the **Tyler Concert**—a night where music, style, and raw emotion come together to create an unforgettable experience! Whether you\'re a long-time fan or a newcomer to Tyler\'s unique sound, this concert promises to be a night you won’t want to miss. Expect a high-energy show, epic visuals, and a deep dive into the artist\'s most iconic tracks. It’s time to vibe with Tyler like never before!\r\n\r\n### About the Artist:\r\nTyler, the Creator is known for his genre-defying music, distinct fashion sense, and boundary-pushing artistic vision. From his early days with Odd Future to his successful solo career, Tyler has always kept fans on their toes, blending hip-hop, R&B, jazz, and alternative sounds into one signature style. With albums like *Flower Boy*, *Igor*, and *Call Me If You Get Lost*, he continues to redefine what it means to be a modern-day artist. His concerts are a perfect reflection of his bold creativity, vibrant energy, and unmatched talent.\r\n\r\n### Concert Highlights:\r\n- **A Sonic Journey Through Tyler’s Discography**: From the gritty, experimental sounds of *Goblin* to the smooth, soulful tracks of *Flower Boy*, Tyler will take you through his incredible career. Expect to hear hits like “EARFQUAKE,” “See You Again,” “Who Dat Boy,” and “IFHY,” as well as tracks from his latest album. The setlist will leave you singing along and feeling every emotion Tyler pours into his music.\r\n\r\n- **Visual Mastery**: Known for his unique aesthetic, Tyler doesn’t just make music—he creates an entire visual experience. His concerts are no different. Expect stunning visuals, innovative stage setups, and mind-blowing projections that bring the music to life in an entirely new way. It’s more than just a concert; it’s a full-on multimedia journey.\r\n\r\n- **Unforgettable Energy**: Tyler’s concerts are legendary for their high-energy performances. The crowd will be buzzing, jumping, and vibing as Tyler commands the stage with his larger-than-life persona. His charisma is unmatched, and he knows how to connect with his audience on a personal level, making every song feel like a shared experience.\r\n\r\n- **Surprise Moments**: Tyler is known for keeping things unpredictable. Whether it’s a surprise guest, an unexpected remix, or a completely new arrangement of a familiar track, you can bet that this concert will have plenty of jaw-dropping moments to keep you on your toes.\r\n\r\n- **Fashion & Style**: When you attend a Tyler concert, you know you’re stepping into a world of creativity and self-expression. From Tyler’s own iconic style to the fashion of the fans around him, expect a show where fashion, music, and art collide. Get ready for a visual feast both on stage and in the crowd.\r\n\r\n- **Exclusive Merch**: No concert is complete without some exclusive merch, and Tyler always delivers when it comes to limited-edition tour items. Whether it’s a tee with custom graphics or a hoodie featuring album artwork, make sure to grab a piece of the tour to remember the night by.\r\n\r\n### Why You’ll Love It:\r\n- **The Full Tyler Experience**: This concert is more than just a live performance; it’s a true immersion into Tyler’s world. Whether you’re a fan of his music, his fashion, or his boundary-pushing creativity, this show will give you everything you love about the artist in one night.\r\n\r\n- **Perfect for Fans of All Ages**: Whether you\'re into Tyler\'s early work with Odd Future or you\'re a fan of his more recent solo projects, there’s something for every fan to enjoy. The diversity of his music means that no matter what era of his career you love most, you’ll find something to vibe with.\r\n\r\n- **A Night to Remember**: Tyler’s concerts are known for creating lasting memories. Whether it’s his electrifying stage presence, the crowd energy, or the overwhelming sense of community, you’ll leave feeling like you’ve just witnessed something truly special.\r\n\r\n### What to Expect:\r\n- **Opening Acts**: Expect some great opening acts who are handpicked to complement Tyler’s genre-defying style. Tyler is all about supporting up-and-coming talent, so you may get to experience a new artist or band that complements the vibe of the night.\r\n\r\n- **Intimate and Massive at the Same Time**: Tyler’s concerts strike the perfect balance between being personal and massive. Even in a large arena, his ability to connect with the audience makes the experience feel intimate. The whole crowd feels like one big family, united by the music and the moment.\r\n\r\n- **An Emotional Ride**: Tyler’s music often touches on themes of identity, love, heartbreak, and self-discovery. Be prepared for moments that are both emotionally intense and deeply personal, as Tyler’s lyrics resonate with fans on a profound level.\r\n\r\n### Tips for the Perfect Concert Experience:\r\n- **Arrive Early**: Make sure to get to the venue early to catch the opening acts and soak in the full atmosphere. Whether you\'re catching up with friends or simply vibing to the pre-show music, it’s best to settle in and enjoy the energy building around you.\r\n  \r\n- **Dress for Comfort & Style**: Tyler’s concerts are known for their fashion-forward crowd. Whether you go for a bold graphic tee, a unique outfit, or something inspired by Tyler’s own style, make sure you\'re dressed to stand out while staying comfortable for a night of jumping, dancing, and singing.\r\n\r\n- **Stay Hydrated**: It’s going to be an intense show, so make sure to drink plenty of water before and after the concert to stay hydrated. With all the energy in the room, you’ll need it!\r\n\r\n- **Capture the Moment**: Don’t forget to take a few pictures or videos, but remember to enjoy the experience as it happens. While it’s tempting to record every second, sometimes it’s best to just live in the moment and soak up the vibes.\r\n\r\n### Conclusion:\r\nThe **Tyler Concert** is more than just a live show—it\'s an immersive experience filled with electrifying performances, unforgettable energy, and stunning visuals. Whether you\'re a long-time fan or a first-time listener, Tyler’s ability to captivate his audience will leave you wanting more. Get ready to dive into the world of Tyler, the Creator, and enjoy a night of music, art, and pure creative brilliance.\r\n\r\nSo, get your tickets, bring your best vibes, and get ready for the *Tyler Concert* of a lifetime! ???','2024-11-19 06:35:19','2024-11-19 06:35:19','00:31:00','13:35:00');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_contacts`
--

DROP TABLE IF EXISTS `message_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_contacts` (
  `email` varchar(259) DEFAULT NULL,
  `subjects` longtext,
  `messages` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_contacts`
--

LOCK TABLES `message_contacts` WRITE;
/*!40000 ALTER TABLE `message_contacts` DISABLE KEYS */;
INSERT INTO `message_contacts` VALUES ('biggiecyber@gmail.com','mistake','vhrthtrhththwhthwtrhtthwthhtwhrthhrwhth'),('biggiecyber@gmail.com','mistake','ddfdsdsfds'),('biggiecyber@gmail.com','mistake','luyrxtugcouyitculyflguvui'),('biggiecyber@gmail.com','mistake','yrfxcuvckfyhviubicgjhfvkijibuyfvy hjkmooikljhg  tuxdgctgvhboughfycf iydutcgvbhinolh.jkgjv  utdgloudyrtuiojpj;lkkv lyccutg'),('biggiecyber@gmail.com','mistake','yrfxcuvckfyhviubicgjhfvkijibuyfvy hjkmooikljhg  tuxdgctgvhboughfycf iydutcgvbhinolh.jkgjv  utdgloudyrtuiojpj;lkkv lyccutg'),('biggiecyber@gmail.com','mistake','ugcuv'),('biggiecyber@gmail.com','mistake','ugcuv'),('biggiecyber@gmail.com','mistake','ugcuv'),('biggiecyber@gmail.com','mistake','ugcuv'),('biggiecyber@gmail.com','mistake','ugcuv'),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),(NULL,NULL,NULL),('biggiecyber@gmail.com','mistake','o8tcu8tt7vbyui'),(NULL,NULL,NULL),('','',''),('','',''),(NULL,NULL,NULL),(NULL,NULL,NULL);
/*!40000 ALTER TABLE `message_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `profile_image` varchar(600) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `first_name` varchar(500) DEFAULT NULL,
  `last_name` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (16,NULL,'ec2020','ericderrick2020@gmail.com','$2y$10$dDjz2t4jHlDri6j/2ds5gezKUrAjjt2QyAbCkj2NFLX.h.6VbxLry','2024-10-22 06:45:43','2024-10-22 06:45:43','Derrick','eric'),(17,NULL,'ks','biggiecyber@gmail.com','$2y$10$tGzJgDTgAM332MD9M9oxFumQ40vd.lN..XzCmQDJhlWSK.aUT7yby','2024-10-24 07:18:46','2024-10-24 07:18:46','kasolo','dickson'),(32,NULL,'cop256','cop@gmail.com','$2y$10$o/RYYKiZWL7jXUBIbSxb5e0leaz//Vxe6Hf5jtRTUERev6uAhCUVa','2024-11-19 09:35:05','2024-11-19 09:35:05','cop','cop1');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 13:37:06
