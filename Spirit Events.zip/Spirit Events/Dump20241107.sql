-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: event_login
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_1_categories`
--

DROP TABLE IF EXISTS `event_1_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_1_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1_categories`
--

LOCK TABLES `event_1_categories` WRITE;
/*!40000 ALTER TABLE `event_1_categories` DISABLE KEYS */;
INSERT INTO `event_1_categories` VALUES (1,'Children',5000.00),(2,'students',60000.00),(3,'VIP',100000.00),(4,'TABLE',500000.00),(5,'FOOD AND DRINKS',1000000.00);
/*!40000 ALTER TABLE `event_1_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_2_categories`
--

DROP TABLE IF EXISTS `event_2_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_2_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_2_categories`
--

LOCK TABLES `event_2_categories` WRITE;
/*!40000 ALTER TABLE `event_2_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_2_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_3_categories`
--

DROP TABLE IF EXISTS `event_3_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_3_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_3_categories`
--

LOCK TABLES `event_3_categories` WRITE;
/*!40000 ALTER TABLE `event_3_categories` DISABLE KEYS */;
INSERT INTO `event_3_categories` VALUES (1,'kids',10000.00),(2,'adults',300000.00),(3,'VVIP',900000.00);
/*!40000 ALTER TABLE `event_3_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_4_categories`
--

DROP TABLE IF EXISTS `event_4_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_4_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_4_categories`
--

LOCK TABLES `event_4_categories` WRITE;
/*!40000 ALTER TABLE `event_4_categories` DISABLE KEYS */;
INSERT INTO `event_4_categories` VALUES (1,'rich gang',40000.00);
/*!40000 ALTER TABLE `event_4_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_crew`
--

DROP TABLE IF EXISTS `event_crew`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_crew` (
  `crew_Name` varchar(500) DEFAULT NULL,
  `crew_Leader` varchar(500) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `event_interest` varchar(500) NOT NULL,
  `crew_size` int DEFAULT NULL,
  `special_skills` varchar(900) DEFAULT NULL,
  PRIMARY KEY (`event_interest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_crew`
--

LOCK TABLES `event_crew` WRITE;
/*!40000 ALTER TABLE `event_crew` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_crew` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `event_id` int NOT NULL AUTO_INCREMENT,
  `event_images` varchar(900) DEFAULT NULL,
  `event_name` varchar(100) NOT NULL,
  `event_date` date DEFAULT NULL,
  `event_location` varchar(100) DEFAULT NULL,
  `event_category` varchar(400) DEFAULT NULL,
  `event_description` longtext,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `event_category` (`event_category`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'../assets/img/uploads/black_man_holding_laptop.png','Computer Gala','2024-10-05','bukeda',NULL,'A colorful computer gala event filled with bright lights, balloons, and happy people! There are computers everywhere, with kids and adults playing games, coding, and learning new things. Some booths have robots moving around, while others show big screens with cool animations. People are wearing fun badges, and there’s music playing to keep everyone excited. It\'s a place where technology feels like a big playground!','2024-10-30 15:21:29','2024-10-30 15:21:29','22:17:00','00:16:00'),(2,'../assets/img/uploads/Screenshot 2024-08-24 004343.png','computer competiton','2024-11-23','kaboja',NULL,'Once upon a time, in a small but technologically forward-thinking town, the annual CodeCraze competition was fast approaching. It was the most anticipated event among young programmers, known for challenging the participants\' coding skills, creativity, and endurance.\r\n\r\nThis year, a group of friends—Liam, Sofia, Ray, and Maya—decided to enter as a team. Each of them had a unique strength: Liam was a master of algorithms, Sofia was the CSS and design wizard, Ray knew databases inside out, and Maya could debug code like a pro. They had been practicing together, spending late nights brainstorming and solving tricky problems in preparation for the big day.\r\n\r\nThe competition began early on a Saturday morning, with dozens of teams seated in front of rows of computers in the town’s tech center. The first challenge was to build a simple game that could engage players for a minimum of five minutes. The clock was ticking as each team feverishly typed away, racing against time.\r\n\r\nLiam and Sofia quickly designed the game concept—a fast-paced puzzle game with a bright, colorful interface that would appeal to a wide range of players. Ray set up the database to store high scores, while Maya debugged each feature as it was implemented, ensuring everything ran smoothly.\r\n\r\nThe judges were impressed with their game and awarded them full points for creativity and functionality. But that was only the beginning.\r\n\r\nThe second challenge was a problem-solving round, where each team had to create a piece of software to analyze and visualize a large dataset. The task was particularly challenging, as the data was complex and included thousands of entries. Liam and Ray worked on algorithms to sort and clean the data, while Sofia crafted a beautiful interface to display the charts and graphs. Maya meticulously tested every visualization, catching a critical bug just minutes before the deadline.\r\n\r\nTheir tool turned out to be one of the most user-friendly and insightful in the competition, winning the judges over once again.\r\n\r\nFinally, they reached the last round: a live debugging session, where each team was handed a code filled with bugs. The fastest team to fix the errors and make the code functional would win the grand prize. Maya’s skills were the star of this round. She kept her cool, quickly spotting and fixing each bug with precision, while her teammates cheered her on.\r\n\r\nAfter hours of intense competition, the scores were tallied, and it was announced: Liam, Sofia, Ray, and Maya’s team had won first place! Their teamwork, dedication, and diverse skills had carried them to victory. As they held up their trophy, they felt proud of what they had accomplished together.','2024-11-04 10:48:42','2024-11-04 10:48:42',NULL,NULL),(3,'../assets/img/uploads/Screenshot 2024-08-24 004657.png','Training for students','2024-11-15','bukeda',NULL,'Once upon a time, in a small but technologically forward-thinking town, the annual CodeCraze competition was fast approaching. It was the most anticipated event among young programmers, known for challenging the participants\' coding skills, creativity, and endurance.\r\n\r\nThis year, a group of friends—Liam, Sofia, Ray, and Maya—decided to enter as a team. Each of them had a unique strength: Liam was a master of algorithms, Sofia was the CSS and design wizard, Ray knew databases inside out, and Maya could debug code like a pro. They had been practicing together, spending late nights brainstorming and solving tricky problems in preparation for the big day.\r\n\r\nThe competition began early on a Saturday morning, with dozens of teams seated in front of rows of computers in the town’s tech center. The first challenge was to build a simple game that could engage players for a minimum of five minutes. The clock was ticking as each team feverishly typed away, racing against time.\r\n\r\nLiam and Sofia quickly designed the game concept—a fast-paced puzzle game with a bright, colorful interface that would appeal to a wide range of players. Ray set up the database to store high scores, while Maya debugged each feature as it was implemented, ensuring everything ran smoothly.\r\n\r\nThe judges were impressed with their game and awarded them full points for creativity and functionality. But that was only the beginning.\r\n\r\nThe second challenge was a problem-solving round, where each team had to create a piece of software to analyze and visualize a large dataset. The task was particularly challenging, as the data was complex and included thousands of entries. Liam and Ray worked on algorithms to sort and clean the data, while Sofia crafted a beautiful interface to display the charts and graphs. Maya meticulously tested every visualization, catching a critical bug just minutes before the deadline.\r\n\r\nTheir tool turned out to be one of the most user-friendly and insightful in the competition, winning the judges over once again.\r\n\r\nFinally, they reached the last round: a live debugging session, where each team was handed a code filled with bugs. The fastest team to fix the errors and make the code functional would win the grand prize. Maya’s skills were the star of this round. She kept her cool, quickly spotting and fixing each bug with precision, while her teammates cheered her on.\r\n\r\nAfter hours of intense competition, the scores were tallied, and it was announced: Liam, Sofia, Ray, and Maya’s team had won first place! Their teamwork, dedication, and diverse skills had carried them to victory. As they held up their trophy, they felt proud of what they had accomplished together.','2024-11-04 10:51:50','2024-11-04 10:51:50',NULL,NULL),(4,'../assets/img/uploads/Screenshot 2024-10-29 080629.png','tv4vt44t','2024-11-02','kampala Uganda',NULL,'At the edge of a quiet town stood the dark, shimmering waters of Willowmere Lake. The locals whispered that strange things happened there, things best left alone. But for 12-year-old Maxine, the lake was a mystery calling her name.\r\n\r\nOne chilly October afternoon, Maxine set out with her flashlight and her dog, Boomer. She’d heard stories about a hidden treasure at the bottom of the lake, left by an eccentric inventor who’d lived in the town decades ago. Determined, she followed the lake’s edge, scanning the ground for any signs of a hidden path or clues.\r\n\r\nAs she rounded a corner, Boomer suddenly froze, his ears perked up. Maxine squinted into the dusky light and noticed an old, rusty lantern lying half-buried in the sand. Picking it up, she dusted it off and noticed faint engravings on its handle: Only the brave shall find what’s buried beneath.\r\n\r\nA spark of excitement lit up in Maxine’s eyes. She didn’t know exactly what she was looking for, but she felt the tingling sense of adventure growing inside her. She continued around the lake until she spotted something unexpected—a small rowboat tethered to a tree with frayed, weathered rope.\r\n\r\nShe climbed into the boat with Boomer at her side and pushed off into the water, rowing toward the center of the lake. As they drifted, the water grew still, reflecting the fiery orange of the setting sun. Suddenly, Boomer let out a soft growl, staring intently into the depths below.\r\n\r\nMaxine peered over the edge and gasped. A faint, golden light pulsed beneath the water. Her heart raced, and she grabbed the rusty lantern, holding it out over the water. Slowly, the light grew brighter, revealing an ancient chest lodged between two rocks.\r\n\r\nWithout thinking, Maxine reached into the chilly water, her fingers brushing against the chest. The moment she touched it, a strange warmth spread through her hand, as if the chest were alive. She pulled it onto the boat, its lock breaking easily in her hands.\r\n\r\nInside, she found a treasure beyond her wildest dreams—not gold, but an array of peculiar devices, each one more fascinating than the last. Blueprints, gadgets, and glass vials filled with glowing liquid. Maxine realized this was the legacy of the long-lost inventor, left for a curious soul like her to uncover.\r\n\r\nFrom that day on, Willowmere Lake had a new legend: the tale of the young adventurer and her discovery of the inventor’s treasure. And Maxine, with her new tools, began a life full of inventions and mysteries, keeping the spirit of the lake alive for generations to come.','2024-11-06 19:58:59','2024-11-06 19:58:59',NULL,NULL);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_contacts`
--

DROP TABLE IF EXISTS `message_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_contacts` (
  `email` varchar(259) DEFAULT NULL,
  `subjects` longtext,
  `messages` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_contacts`
--

LOCK TABLES `message_contacts` WRITE;
/*!40000 ALTER TABLE `message_contacts` DISABLE KEYS */;
INSERT INTO `message_contacts` VALUES ('biggiecyber@gmail.com','mistake','vhrthtrhththwhthwtrhtthwthhtwhrthhrwhth'),('biggiecyber@gmail.com','mistake','ddfdsdsfds');
/*!40000 ALTER TABLE `message_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `event_name` varchar(255) DEFAULT NULL,
  `ticket_id` varchar(50) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(20) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `profile_image` varchar(600) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `first_name` varchar(500) DEFAULT NULL,
  `last_name` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (16,NULL,'ec2020','ericderrick2020@gmail.com','$2y$10$dDjz2t4jHlDri6j/2ds5gezKUrAjjt2QyAbCkj2NFLX.h.6VbxLry','2024-10-22 06:45:43','2024-10-22 06:45:43','Derrick','eric'),(17,NULL,'ks','biggiecyber@gmail.com','$2y$10$tGzJgDTgAM332MD9M9oxFumQ40vd.lN..XzCmQDJhlWSK.aUT7yby','2024-10-24 07:18:46','2024-10-24 07:18:46','kasolo','dickson');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-07  9:55:58
