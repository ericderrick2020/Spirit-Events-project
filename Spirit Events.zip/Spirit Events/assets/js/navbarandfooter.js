// FOR CURRENT DATETIME AND
document.getElementById('date').innerText= new Date().getFullYear();

function mobileNavViewer() {
    const navbar = document.getElementById("bars");
    const icon = document.getElementById("icon"); 
    
    if (navbar.style.display === "none" || navbar.style.display === "") {
        navbar.style.display = "block";
        icon.classList.remove("fa-solid fa-bars");
        icon.classList.add("fa-solid fa-x");
    } else {
        navbar.style.display = "none";
        icon.classList.remove("fa-solid fa-x");
        icon.classList.add("fa-solid fa-bars");
    }
}