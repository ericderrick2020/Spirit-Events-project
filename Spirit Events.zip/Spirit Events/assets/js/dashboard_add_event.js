// To display the image in the image display container
document.getElementById('imageInput').addEventListener('change', function(event) {
    const imageDisplay = document.getElementById('imageDisplay');
    const file = event.target.files[0];

    if (file) {
        const reader = new FileReader();

        reader.onload = function(e) {
            imageDisplay.innerHTML = `<img src="${e.target.result}" alt="Selected Image" style="max-width: 100%; height: auto;">`;
        };

        reader.readAsDataURL(file);
    } else {
        imageDisplay.innerHTML = ''; // Clear the display if no file is selected
    }
});

// Select necessary elements
const addBtn = document.getElementById('addBtn');
const inputContainer = document.getElementById('inputContainer');

// Add event listener to the button to generate table rows with input fields
addBtn.addEventListener('click', () => {
    const row = document.createElement('tr');

    // Create a cell with an input field for the cost
    const costCell = document.createElement('td');
    const costInput = document.createElement('input');
    costInput.setAttribute('type', 'number');
    costInput.setAttribute('placeholder', 'Cost');
    costInput.setAttribute('name', 'venueCost[]');
    costInput.style.width = '100px';
    costCell.appendChild(costInput);

    // Create a cell with an input field for the category
    const categoryCell = document.createElement('td');
    const categoryInput = document.createElement('input');
    categoryInput.setAttribute('type', 'text');
    categoryInput.setAttribute('placeholder', 'Category ID');
    categoryInput.setAttribute('name', 'venueCategory[]'); // Make sure this is included
    categoryInput.style.width = '100px';
    categoryCell.appendChild(categoryInput);

    // Create a delete button inside a table cell
    const deleteCell = document.createElement('td');
    const deleteRow = document.createElement('button');
    deleteRow.textContent = 'Delete';
    deleteRow.style.width = '100px';
    deleteRow.style.height = '36px';
    deleteRow.style.backgroundColor = 'red';
    deleteRow.style.color = 'white';
    deleteRow.style.border = 'none';
    deleteRow.style.cursor = 'pointer';
    deleteRow.style.borderRadius = '0px';

    // Add click event to delete the row
    deleteRow.addEventListener('click', () => {
        row.remove();
    });

    deleteCell.appendChild(deleteRow);

    // Append cells to the row and the row to the table body
    row.appendChild(costCell);
    row.appendChild(categoryCell);
    row.appendChild(deleteCell);
    inputContainer.appendChild(row);
});