const inputnum = document.getElementById('tickets');


function notickets(){
    
}