// // const ticketPrice = 20; // Define the price of one ticket

// // function updateTotal() {
// //     const numOfTickets = document.getElementById("nooftickets").value;
// //     const totalAmount = ticketPrice * numOfTickets; // Calculate total amount
// //     document.getElementById("totalAmount").textContent = totalAmount; // Display total amount
// // }

// function showPaymentFields() {
//     const paymentSelect = document.getElementById("pgate").value;
//     const paymentInfo = document.getElementById("payment-info");
//     const mtnPayment = document.getElementById("mtn-payment");
//     const cardPayment = document.getElementById("card-payment");
//     const mtnPaymentContainer = document.getElementById("mtn-payment-container");
//     const cardPaymentContainer = document.getElementById("card-payment-container");

//     // Hide all payment options initially
//     paymentInfo.style.display = "none";
//     mtnPayment.style.display = "none";
//     cardPayment.style.display = "none";
//     mtnPaymentContainer.style.display = "none";
//     cardPaymentContainer.style.display = "none";

//     // Display the appropriate payment option
//     if (paymentSelect === "mtn") {
//         paymentInfo.style.display = "block";
//         mtnPayment.style.display = "block";
//         mtnPaymentContainer.style.display = "block"; // Show MTN Pay Now button
//     } else if (paymentSelect === "card") {
//         paymentInfo.style.display = "block";
//         cardPayment.style.display = "block";
//         cardPaymentContainer.style.display = "block"; // Show Card Pay Now button
//     }
// }

// // Functions for processing payments
// function processMtnPayment() {
//     const mtnNumber = document.getElementById("mtn-number").value.trim();

//     if (mtnNumber.length === 10) {
//         alert("Processing MTN payment for number: " + mtnNumber);
//     } else {
//         alert("Please enter a valid MTN number.");
//     }
// }

// function processCardPayment() {
//     const cardNumber = document.getElementById("cardNumber").value.trim();
//     const expiryDate = document.getElementById("expiryDate").value;
//     const cvv = document.getElementById("cvv").value.trim();

//     if (cardNumber.length === 16 && expiryDate && cvv.length === 3) {
//         alert("Processing Card payment for card number: " + cardNumber);
//     } else {
//         alert("Please enter valid card details.");
//     }
// }

const cardcont = document.getElementById('card-pay');
const mobpay = document.getElementById('mob-pay');
cardcont.classList.add('hidden');

function displayMobile() {
    // Show mobile pay form and hide card pay form
    mobpay.classList.add('visible');
    mobpay.classList.remove('hidden');
    cardcont.classList.add('hidden');
    cardcont.classList.remove('visible');
}

function displayCard() {
    // Show card pay form and hide mobile pay form
    cardcont.classList.add('visible');
    cardcont.classList.remove('hidden');
    mobpay.classList.add('hidden');
    mobpay.classList.remove('visible');
}