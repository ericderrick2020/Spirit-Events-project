const mtn = document.getElementById('mtn');
const airtel = document.getElementById('airtel');
const card = document.getElementById('card');

function mtnclick(){
    mtn.style.display = "block";
    airtel.style.display = "none";
    card.style.display = "none";
}
function airtelclick(){
    airtel.style.display = "block";
    mtn.style.display = "none";
    card.style.display = "none";
}
function cardclick(){
    airtel.style.display = "none";
    mtn.style.display = "none";
    card.style.display = "block";
}