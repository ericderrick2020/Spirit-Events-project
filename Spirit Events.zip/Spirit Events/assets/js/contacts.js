// const email = document.getElementById('email');
// const subject = document.getElementById('subject');
// const message = document.getElementById('message');

// if(message.inputMode === ""){
//     alert("Fill in all the spaces");
// }
// if(email.inputMode === ""){
//     alert("Fill in all the spaces");
// }
// if(email.inputMode === ""){
//     alert("Fill in all the spaces");
// }