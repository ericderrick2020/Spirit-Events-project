<?php
require 'conn.php';
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

$query = "SELECT * FROM events ORDER BY ";
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- WEBSITE TITLE -->
    <title>Home | Spirit Events</title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/payment-fill-up.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbar1" id="navbar1">
        <div class="logo">
            <h2>SimEvents</h2>
        </div>
        <div class="link-to-pages">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
        </div>
        <div class="profile-side">
            <span><?php echo $_SESSION['username']; ?></span>
        </div>
    </nav>
    <!-- HERO SECTION START -->
    <main>
        <form action="user-receipt-page.php" method="post">  
            <div class="payment-box">
                <h2>Payment Information</h2>
                <div class="payment-input">
                    <label for="fname">Full Name</label>
                    <input type="text" name="fname" id="fname" required>
                </div>
                <div class="payment-input">
                    <label for="fname">Email</label>
                    <input type="email" name="email" id="fname">
                </div>
                <div class="payment-input">
                    <label for="fname">Tel no.</label>
                    <input type="tel" name="number" id="fname">
                </div>
                <div class="payment-gateway-opt">
                    <div class="pay-opt-btn" onclick="mtnclick()">
                        <img src="../assets/img/mtn-icon.png" alt="">
                    </div>
                    <div class="pay-opt-btn" onclick="airtelclick()">
                        <img src="../assets/img/airtel-icon.png" alt="">
                    </div>
                    <div class="pay-opt-btn" onclick="cardclick()">
                        <img src="../assets/img/card-icon.png" alt="">
                    </div>
                </div>
                <div class="payment-container">
                    <div class="pay-cont-mtn" id ="mtn">
                        <form action=".receipt.php" method="post">
                            <div class="pay-cont">
                                <label for="telno">Enter Phone Number to Carry Purchase</label>
                                <input type="tel" name="telno" id="telno" placeholder="">
                            </div>
                            <div class="pay-cont">
                                <span class="amount" id = "amount" name = "amount">Shs. 50000</span>
                            </div>
                            <button type="submit">Pay Now</button>
                        </form>
                    </div>
                    <div class="pay-cont-airtel" id ="airtel">
                        <form action=".receipt.php" method="post">
                            <div class="pay-cont">
                                <label for="telno">Enter Phone Number to Carry Purchase</label>
                                <input type="tel" name="telno" id="telno" placeholder="">
                            </div>
                            <div class="pay-cont">
                                <span class="amount" id = "amount" name = "amount">Shs. 30000</span>
                            </div>
                            <button type="submit">Pay Now</button>
                        </form>
                    </div>
                    <div class="pay-cont-airtel" id ="card">
                        <form action=".receipt.php" method="post">
                            <div class="pay-cont">
                                <input type="tel" name="telno" id="telno" placeholder="Full Name">
                            </div>
                            <div class="pay-cont">
                                <input type="tel" name="telno" id="telno" placeholder="Card Number">
                            </div>
                            <div class="pay-cont-row">
                                <input type="text" name="telno" id="telno" placeholder="Exp">
                                <input type="text" name="telno" id="telno" placeholder="CVV">
                            </div>
                            <div class="pay-cont">
                                <span class="amount" id = "amount" name = "amount">Shs. 30000</span>
                            </div>
                            <button type="submit">Pay Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </form>
    </main>
    <!-- FOOTER START -->
    <!-- <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.html">Careers</a></li>
                    <li><a href="sponsors.html">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="faqs.html">FAQs</a></li>
                    <li><a href="helpcenter.html">Help Center</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#navbar1">Home</a></li>
                    <li><a href="events.html">Events</a></li>
                    <li><a href="calendar.html">Calendar</a></li>
                    <li><a href="aboutus.html">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SPIRIT EVENTS. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer> -->
    <!-- FOOTER END -->
    <!-- JAVASCRIPT LINKS -->
    <script src="../assets/js/navbarandfooter.js"></script>
    <script src="../assets/js/payment-fill-up.js"></script>
</body>

</html>