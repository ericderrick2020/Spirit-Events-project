<?php
// payment.php
require 'conn.php';
session_start();
include('phpqrcode/qrlib.php');

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

$amount = isset($_GET['amount']) ? intval($_GET['amount']) : 0;
$event_id = isset($_GET['event_id']) ? intval($_GET['event_id']) : 1;

if (isset($_POST['submitPayment'])) {
    $fullName = $_POST['fullName'];
    $noOfTickets = intval($_POST['nooftickets']);
    $paymentMethod = $_POST['pgate'];
    $amountPaid = $amount * $noOfTickets;
    $ticketID = rand(1000, 9999); // Generate unique ticket ID
    $email = $_POST['email'];

    // Generate QR code
    $tempDir = "../assets/img/qrcodes/";
    $codeContents = "Ticket ID: $ticketID | Name: $fullName | Event ID: $event_id";
    $fileName = 'ticket_' . md5($codeContents) . '.png';
    $pngAbsoluteFilePath = $tempDir . $fileName;

    if (!file_exists($pngAbsoluteFilePath)) {
        QRcode::png($codeContents, $pngAbsoluteFilePath);
    }

    // Store ticket in the database
    $stmt = $conn->prepare("INSERT INTO tickets (ticket_id, user_id, full_name, event_id, qr_code, amount, payment_method, purchase_date, email) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)");
    $stmt->bind_param("iisissds", $ticketID, $_SESSION['user_id'], $fullName, $event_id, $fileName, $amountPaid, $paymentMethod, $email);

    if ($stmt->execute()) {
        header("Location: user-receipt-page.php?ticketID=$ticketID&event_id=$event_id&qr=$fileName");
        exit;
    } else {
        echo "Failed to store ticket. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- WEBSITE TITLE -->
    <title>Home </title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/payment-fill-up.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
    <!-- HERO SECTION START -->
    <main>
        <form action="" method="post">
            <div class="payment-field-container">
                <div class="payment-field">
                    <label for="fname">Name on Ticket</label>
                    <input type="text" name="fullName" id="fullName" required>
                </div>

                <div class="payment-field-two">
                    <div class="inner-one">
                        <label for="nooftickets">Number of Tickets</label>
                        <input type="number" name="nooftickets" id="nooftickets" min="1" class="no-arrows" required onchange="updateTotal()" oninput="updateTotal()">
                    </div>

                    <div class="inner-one">
                        <label for="pgate">Payment Methods</label>
                        <select name="pgate" id="pgate" onchange="showPaymentFields()">
                            <option value="default" selected>CHOOSE PAYMENT METHOD</option>
                            <option value="mtn">MTN/AIRTEL</option>
                            <option value="card">CARD</option>
                        </select>
                    </div>
                </div>

                <div class="pay-opt-container" id="payment-info" style="display: none; margin-top: 15px;">
                    <div class="mtn" id="mtn-payment" style="display: none;">
                        <label for="mtn-number">Enter MTN / Number</label>
                        <input type="text" name="number" id="mtn-number" maxlength="10" placeholder="07XXXXXXXX" required>
                        <div class="total-amount">
                            <strong>Category:</strong> <?php echo $category; ?><br>
                            <strong>Total Amount: </strong> UGX <span id="totalAmountDisplay"><?php echo number_format($amount, 2); ?></span>
                        </div>
                        <div id="mtn-payment-container" style="display: none; margin-top: 15px;">
                            <button type="submit" name="submitPayment">Pay Now UGX <span id="totalAmount">0</span></button>
                        </div>
                    </div>

                    <div class="card" id="card-payment" style="display: none;">
                        <label for="cardNumber">Card Number</label>
                        <input type="text" id="cardNumber" maxlength="16" placeholder="1234 5678 9012 3456" required>

                        <div class="payment-field-two" style="margin-top: 10px;">
                            <div class="inner-one">
                                <label for="expiryDate">Expiry Date</label>
                                <input type="month" id="expiryDate" required>
                            </div>

                            <div class="inner-one">
                                <label for="cvv">CVV</label>
                                <input type="text" id="cvv" maxlength="3" placeholder="123" required>
                            </div>
                        </div>
                        <div class="total-amount">
                            <strong>Category:</strong> <?php echo $category; ?><br>
                            <strong>Total Amount: </strong> UGX <span id="totalAmountDisplay2"><?php echo number_format($amount, 2); ?></span>
                        </div>
                        <div id="card-payment-container" style="display: none; margin-top: 15px;">
                            <button type="submit" name="submitPayment">Pay Now UGX <span id="totalAmount">0</span></button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <script>
            function updateTotal() {
                const ticketCount = document.getElementById("nooftickets").value;
                const ticketAmount = <?php echo $amount; ?>;
                const totalAmount = ticketCount * ticketAmount;
                document.getElementById("totalAmountDisplay").innerText = totalAmount.toFixed(2);
                document.getElementById("totalAmountDisplay2").innerText = totalAmount.toFixed(2);
            }

            updateTotal();
        </script>
    </main>
    <!-- FOOTER START -->

    <!-- FOOTER END -->
    <!-- JAVASCRIPT LINKS -->
    <script src="../assets/js/navbarandfooter.js"></script>
    <script src="../assets/js/payment-fill-up.js"></script>
</body>

</html>