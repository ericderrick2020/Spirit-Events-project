<?php
require 'conn.php';
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}


$id = intval($_GET['id']);

$stmt =  $conn->prepare("SELECT * FROM event_{$id}_categories where event_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();




?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- WEBSITE TITLE -->
    <title>Home | Spirit Events</title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/payment-fill-up.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
<nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
    <!-- HERO SECTION START -->
    <main>
        <form action="" method="post">
            <div class="payment-field-container">
                <div class="payment-field">
                    <label for="fname">Name on Ticket</label>
                    <input type="text" name="fullName" id="fullName" required>
                </div>

                <div class="payment-field-two">
                    <div class="inner-one">
                        <label for="nooftickets">Number of Tickets</label>
                        <input type="number" name="nooftickets" id="nooftickets" min="1" class="no-arrows" required onchange="updateTotal()" oninput="updateTotal()">
                    </div>

                    <div class="inner-one">
                        <label for="pgate">Payment Methods</label>
                        <select name="pgate" id="pgate" onchange="showPaymentFields()">
                            <option value="default" selected>CHOOSE PAYMENT METHOD</option>
                            <option value="mtn">MTN</option>
                            <option value="airtel">AIRTEL</option>
                            <option value="card">CARD</option>
                        </select>
                    </div>
                </div>

                <div class="pay-opt-container" id="payment-info" style="display: none; margin-top: 15px;">
                    <div class="mtn" id="mtn-payment" style="display: none;">
                        <label for="mtn-number">Enter MTN /  Number</label>
                        <input type="text" name="number" id="mtn-number" maxlength="10" placeholder="07XXXXXXXX" required>
                        <div id="mtn-payment-container" style="display: none; margin-top: 15px;">
                            <button type="button" onclick="processMtnPayment()">Pay Now <span id="totalAmount">0</span></button>
                        </div>
                    </div>

                    <div class="card" id="card-payment" style="display: none;">
                        <label for="cardNumber">Card Number</label>
                        <input type="text" id="cardNumber" maxlength="16" placeholder="1234 5678 9012 3456" required>

                        <div class="payment-field-two" style="margin-top: 10px;">
                            <div class="inner-one">
                                <label for="expiryDate">Expiry Date</label>
                                <input type="month" id="expiryDate" required>
                            </div>

                            <div class="inner-one">
                                <label for="cvv">CVV</label>
                                <input type="text" id="cvv" maxlength="3" placeholder="123" required>
                            </div>
                        </div>
                        <div id="card-payment-container" style="display: none; margin-top: 15px;">
                            <button type="button" onclick="processCardPayment()">Pay Now <span id="totalAmount">0</span></button>
                        </div>
                    </div>
                </div>

                <div class="total-amount" style="margin-top: 20px;">
                    <strong>Total Amount: </strong>
                    
                </div>
            </div>
        </form>
    </main>
    <!-- FOOTER START -->
    <!-- <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.html">Careers</a></li>
                    <li><a href="sponsors.html">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="faqs.html">FAQs</a></li>
                    <li><a href="helpcenter.html">Help Center</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#navbar1">Home</a></li>
                    <li><a href="events.html">Events</a></li>
                    <li><a href="calendar.html">Calendar</a></li>
                    <li><a href="aboutus.html">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SPIRIT EVENTS. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer> -->
    <!-- FOOTER END -->
    <!-- JAVASCRIPT LINKS -->
    <script src="../assets/js/navbarandfooter.js"></script>
    <script src="../assets/js/payment-fill-up.js"></script>
</body>

</html>