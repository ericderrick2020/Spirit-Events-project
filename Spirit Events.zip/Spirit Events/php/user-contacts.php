<?php
include 'conn.php';
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$query =  $conn->prepare("INSERT INTO message_contacts (email, subjects, messages)  VALUES (?, ?, ?)");

if ($query) {
    $query->bind_param("sss", $email, $subject, $message);

    if ($query->execute()) {
        $succsend = "Sent successfully";
    } else {
        echo "Error: " . $query->error;
    }

    $query->close();
} else {
    echo "Error: " . $conn->error;
}


$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | Spirit Events</title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/contact.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
    <main>
        <section class="section-1-contacts">
            <h1>Contact Us</h1>
            <div class="contact-container">
                <div class="side-1-form">
                    <h2>Send us a message</h2>
                    <form method="post">
                        <div class="input-container">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email">
                        </div>
                        <div class="input-container">
                            <label for="subject">Subject</label>
                            <input type="text" name="subject" id="subject">
                        </div>
                        <div class="input-container">
                            <label for="message">Message</label>
                            <textarea name="message" id="message"></textarea>
                        </div>
                        <button type="submit">Send Message</button>
                    </form>
                </div>
                <div class="side-2-form">
                    <div class="side-2-info">
                        <h2>Contact Information</h2>
                        <hr>
                        <ul class="contact-info">
                            <li><i class="fa-solid fa-location-dot"></i> MEDIA PLAZA, Kira Rd, Kampala</li>
                            <li><i class="fa-solid fa-phone"></i> <a href="tel:0759 100008">0759 100008</a></li>
                            <li><i class="fa-solid fa-envelope"></i> <a href="mailto:spiritevents@gmail.com"
                                    target="_blank">spiritevents@gmail.com</a></li>
                        </ul>
                    </div>
                    <div class="side-2-info">
                        <h2>Businesss Hours</h2>
                        <hr>
                        <p><i class="fa-solid fa-clock"></i> Open 24-hours</p>
                    </div>
                    <div class="side-2-info">
                        <h2>Follow Us</h2>
                        <hr>
                        <div class="media-grp">
                            <a href="https://www.instagram.com" target="_blank" aria-label="Instagram"><i
                                    class="fa-brands fa-instagram"></i></a>
                            <a href="https://www.twitter.com" target="_blank" aria-label="X"><i
                                    class="fa-brands fa-x-twitter"></i></a>
                            <a href="https://www.facebook.com" target="_blank" aria-label="Facebook"><i
                                    class="fa-brands fa-facebook"></i></a>
                            <a href="https://www.linkedin.com" target="_blank" aria-label="LinkedIn"><i
                                    class="fa-brands fa-linkedin"></i></a>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.html">Careers</a></li>
                    <li><a href="sponsors.html">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="faqs.html">FAQs</a></li>
                    <li><a href="helpcenter.html">Help Center</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#navbar1">Home</a></li>
                    <li><a href="events.html">Events</a></li>
                    <li><a href="calendar.html">Calendar</a></li>
                    <li><a href="aboutus.html">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SPIRIT EVENTS. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>
    <script src="../assets/js/navbarandfooter.js"></script>
    <script src="../assets/js/contacts.js"></script>
</body>

</html>