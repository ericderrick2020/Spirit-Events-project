<?php
include 'conn.php'; // Include the database connection file
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit;
}

// Validate the date parameter
if (isset($_GET['date']) && !empty($_GET['date'])) {
    $date = $_GET['date'];

    // Sanitize the date input to prevent SQL injection
    $date = $conn->real_escape_string($date);

    // Prepare the SQL statement to fetch events for the specific date
    $sql = "SELECT event_name FROM events WHERE event_date = '$date'";
    $result = $conn->query($sql);

    $events = [];
    if ($result->num_rows > 0) {
        // Fetch each event name and store it in the events array
        while ($row = $result->fetch_assoc()) {
            $events[] = $row['event_name'];
        }
    }

    // Return the events as a JSON response
    echo json_encode($events);
} else {
    // Return an empty JSON array if the date is not valid
    // echo json_encode([]); // Ensure the function always returns valid JSON
}

$conn->close(); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar</title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700&display=swap" rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/calendar.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
    <main>
        <div class="calendar-container">
            <div class="calendar-header">
                <button id="prev-month" onclick="changeMonth(-1)">&#10094;</button>
                <h2 id="month-year"></h2>
                <button id="next-month" onclick="changeMonth(1)">&#10095;</button>
            </div>
            <div class="calendar-grid" id="calendar-grid">
                <ul>
                    <li>Mon</li>
                </ul>
            </div>
        </div>
    </main>
    <script>
        const calendarGrid = document.getElementById('calendar-grid');
        const monthYearDisplay = document.getElementById('month-year');
        let currentDate = new Date();

        function renderCalendar() {
            const year = currentDate.getFullYear();
            const month = currentDate.getMonth();
            monthYearDisplay.innerText = currentDate.toLocaleString('default', {
                month: 'long'
            }) + ' ' + year;
            calendarGrid.innerHTML = '';

            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const daysInMonth = lastDay.getDate();

            for (let i = 0; i < firstDay.getDay(); i++) {
                calendarGrid.innerHTML += `<div></div>`;
            }

            for (let day = 1; day <= daysInMonth; day++) {
                const eventDate = new Date(year, month, day);
                const formattedDate = eventDate.toISOString().split('T')[0];

                // Create a container for each day and display the day number
                const dayCell = document.createElement('div');
                dayCell.innerHTML = `<strong>${day}</strong>`;
                calendarGrid.appendChild(dayCell);

                // Fetch events for each specific date
                getEventsForDate(formattedDate, dayCell);
            }
        }

        function changeMonth(delta) {
            currentDate.setMonth(currentDate.getMonth() + delta);
            renderCalendar();
        }

        async function getEventsForDate(date, dayCell) {
            try {
                const response = await fetch(`user_calendar.php?date=${date}`);
                if (response.ok) {
                    const events = await response.json();
                    events.forEach(eventName => {
                        // Create a div for each event and append it to the day cell
                        const eventDiv = document.createElement('div');
                        eventDiv.classList.add('event');
                        eventDiv.innerText = eventName;
                        dayCell.appendChild(eventDiv);
                    });
                } else {
                    console.error('Failed to fetch events');
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }

        renderCalendar();
    </script>
</body>

</html>