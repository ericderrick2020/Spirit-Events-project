<?php
// echo "Generate QR Code Test";
include 'conn.php';
include('phpqrcode/qrlib.php');

// Directory to store the generated QR codes
$tempDir = "../assets/img/qrcodes/";

// Example content for the QR code
$eventName = "End of year party";
$ticketID = rand(1000, 9999);  // Example random ticket ID
$codeContents = "Event: $eventName | Ticket ID: $ticketID";

// Generate a unique file name for the QR code
$fileName = 'ticket_' . md5($codeContents) . '.png';
$pngAbsoluteFilePath = $tempDir . $fileName;
$urlRelativeFilePath = $tempDir . $fileName;

// Generate the QR code if it doesn't already exist
if (!file_exists($pngAbsoluteFilePath)) {
    QRcode::png($codeContents, $pngAbsoluteFilePath);
    // echo 'QR Code generated!';
} else {
    echo 'QR Code already exists. Using cached version!';
}

// Create the receipt using HTML and CSS

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/user-receipt-page.css">
    <title>Ticket Receipt</title>
</head>

<body>
    <div class="ticket-container">
        <div class="ticket-header">🎟️ Ticket Receipt</div>
        <div class="ticket-details">
            <p>Event: <strong><?php echo $eventName; ?></strong></p>
            <p>Ticket ID: <strong>#<?php echo $ticketID; ?></strong></p>
        </div>
        <div class="qr-code">
            <img src="<?php echo $urlRelativeFilePath; ?>" alt="QR Code" />
        </div>
        <div class="footer">Thank you for your purchase!</div>
    </div>
</body>

</html>