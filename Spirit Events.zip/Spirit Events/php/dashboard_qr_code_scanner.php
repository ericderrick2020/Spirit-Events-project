<?php
require '../php/conn.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collecting data from form
    $eventname = $_POST['event-name'];
    $eventdate = $_POST['date'];
    $event_location = $_POST['Location-name'];
    $event_description = $_POST['describe'];
    $venueNames = $_POST['venueName'] ?? [];
    $venueCosts = $_POST['venueCost'] ?? [];
    $venueCategories = $_POST['venueCategory'] ?? [];

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $targetDir = "../assets/img/uploads/"; // Ensure this directory exists and is writable
        $targetFile = $targetDir . basename($_FILES['image']['name']); // Get the file path

        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            // Insert event data into the events table
            $stmt = $conn->prepare(
                "INSERT INTO events (event_images, event_name, event_date, event_location, event_description) 
                 VALUES (?, ?, ?, ?, ?)"
            );
            $stmt->bind_param("sssss", $targetFile, $eventname, $eventdate, $event_location, $event_description);

            if ($stmt->execute()) {
                // If the event is inserted, insert venue/category data
                $eventId = $conn->insert_id; // Get the last inserted event ID
                $venueStmt = $conn->prepare(
                    "INSERT INTO event_category_table (category_title, prices) 
                     VALUES (?, ?)"
                );

                foreach ($venueNames as $index => $venueName) {
                    $venueCost = $venueCosts[$index] ?? 0;
                    $venueCategory = $venueCategories[$index] ?? '';

                    $venueStmt->bind_param("sd", $venueCategory, $venueCost);
                    if (!$venueStmt->execute()) {
                        echo "Error adding venue: " . $venueStmt->error;
                    }
                }

                echo "Event and venues added successfully!";
            } else {
                echo "Error adding event: " . $stmt->error;
            }

            // Close statements
            $stmt->close();
            $venueStmt->close(); // Ensure this line is not commented

            // Redirect to the form page
            header("Location: ./dashboard_event.php");
            exit();
        } else {
            echo "Error moving uploaded file.";
        }
    } else {
        echo "Error uploading image.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dasboard_general.css">
    <script defer src="../assets/js/dashboard_general.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard_qr_code_scanner.css">
</head>

<body>
    <div class="dashboard">
        <nav class="top-bar">
            <h1>Events Dashboard</h1>
        </nav>

        <nav class="sidebar">
            <ul class="nav-links">
                <li><a href="dashboard_home.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="dashboard_event.php"><i class="fas fa-calendar-alt"></i> Event Planning</a></li>
                <li><a href="dashboard_attendence.php"><i class="fas fa-ticket-alt"></i> Attendance</a></li>
                <li><a href="#"><i class="fas fa-money-bill-wave"></i> QR Code Scanner</a></li>
                <li><a href="#"><i class="fas fa-users"></i> Analytics</a></li>
                <li><a href="#"><i class="fas fa-chart-line"></i> Reports</a></li>
                <li><a href="#"><i class="fa fa-plus"></i> Add Blogs</a></li>
            </ul>
        </nav>
        <div class="content-side">
            <h2>Qr code Scanner Dashboard</h2>
            <section class="qr-code-page-cards">
                <div class="page-card">
                    <span class="card-heading">Tickets Scanned</span>
                    <span class="card-number">0</span>
                </div>
                <div class="page-card">
                    <span class="card-heading">Tickets Scanned</span>
                    <span class="card-number">0</span>
                </div>
                <div class="page-card">
                    <span class="card-heading">Tickets Scanned</span>
                    <span class="card-number">0</span>
                </div>
            </section>
            <section class="qr-scanner-machine">
                <h3>Scan QR Code</h3>
                <br>
                <div class="box-sim">
                    <div class="scan-qr-code-cam">
                        <div class="qr-scanner-machine-1">
                            <h4>Scan QR code</h4>
                            <div class="camera-scanner">

                            </div>
                            <button>Start Scanning</button>
                        </div>
                        <div class="scanned-codes-card">
                            <h3>Scanned Codes Logs</h3>
                            <div class="card-lists">
                                <br>
                                <table>
                                    <thead>
                                        <td>Card No.</td>
                                        <td>Card Name</td>
                                        <td>Card </td>
                                    </thead>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <script src="../assets/js/dashboard_attendence.js"></script>
</body>

</html>