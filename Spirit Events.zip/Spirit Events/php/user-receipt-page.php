<?php
// Capture URL parameters
$ticketID = isset($_GET['ticketID']) ? $_GET['ticketID'] : 'Unknown';
$eventID = isset($_GET['event_id']) ? $_GET['event_id'] : 'Unknown';
$eventName = isset($_GET['eventName']) ? $_GET['eventName'] : 'Unknown Event';
$qrFile = isset($_GET['qr']) ? $_GET['qr'] : 'default.png';
$amountPaid = isset($_GET['amountPaid']) ? $_GET['amountPaid'] : '0.00';
$fullName = isset($_GET['fullName']) ? $_GET['fullName'] : 'Guest';

// Directory to store the generated QR codes
$tempDir = "../assets/img/qrcodes/";
$qrFilePath = $tempDir . $qrFile;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/user-receipt-page.css">
    <title>Ticket Receipt</title>
</head>

<body>
    <div class="ticket-container">
        <div class="ticket-header">🎟️ Ticket Receipt</div>
        <div class="ticket-details">
            <p>Event: <strong><?php echo htmlspecialchars($eventName); ?></strong></p>
            <p>Ticket ID: <strong>#<?php echo htmlspecialchars($ticketID); ?></strong></p>
            <p>Full Name: <strong><?php echo htmlspecialchars($fullName); ?></strong></p>
            <p>Amount Paid: <strong>UGX <?php echo number_format($amountPaid, 2); ?></strong></p>
        </div>
        <div class="qr-code">
            <img src="<?php echo $qrFilePath; ?>" alt="QR Code" />
        </div>
        <div class="footer">Thank you for your purchase!</div>
    </div>
</body>

</html>