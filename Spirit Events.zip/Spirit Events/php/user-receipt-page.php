<?php
// echo "Generate QR Code Test";

include('phpqrcode/qrlib.php');

// Directory to store the generated QR codes
$tempDir = "../assets/img/qrcodes/";

// Example content for the QR code
$eventName = "End of year party";
$ticketID = rand(1000, 9999);  // Example random ticket ID
$codeContents = "Event: $eventName | Ticket ID: $ticketID";

// Generate a unique file name for the QR code
$fileName = 'ticket_' . md5($codeContents) . '.png';
$pngAbsoluteFilePath = $tempDir . $fileName;
$urlRelativeFilePath = $tempDir . $fileName;

// Generate the QR code if it doesn't already exist
if (!file_exists($pngAbsoluteFilePath)) {
    QRcode::png($codeContents, $pngAbsoluteFilePath);
    // echo 'QR Code generated!';
} else {
    echo 'QR Code already exists. Using cached version!';
}

// Create the receipt using HTML and CSS
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .ticket-container {
            background-color: white;
            width: 400px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }
        .ticket-header {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
        }
        .ticket-details {
            margin: 15px 0;
            font-size: 18px;
        }
        .qr-code {
            margin-top: 20px;
        }
        .footer {
            margin-top: 10px;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="ticket-container">
        <div class="ticket-header">🎟️ Ticket Receipt</div>
        <div class="ticket-details">
            <p>Event: <strong><?php echo $eventName; ?></strong></p>
            <p>Ticket ID: <strong>#<?php echo $ticketID; ?></strong></p>
        </div>
        <div class="qr-code">
            <img src="<?php echo $urlRelativeFilePath; ?>" alt="QR Code" />
        </div>
        <div class="footer">Thank you for your purchase!</div>
    </div>
</body>
</html>