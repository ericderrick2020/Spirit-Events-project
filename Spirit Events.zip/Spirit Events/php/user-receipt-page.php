<?php
// receipt.php
$ticketID = $_GET['ticketID'];
$qrCodePath = "../assets/img/qrcodes/" . $_GET['qr'];
$eventID = $_GET['event_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket Receipt</title>
</head>
<body>
    <div class="ticket-container">
        <h2>Ticket Receipt for <?php echo $fullName ?></h2>
        <p>Ticket ID: <?php echo $ticketID; ?></p>
        <p>Event ID: <?php echo $eventID; ?></p>
    
        <div>
            <img src="<?php echo htmlspecialchars($qrCodePath); ?>" alt="QR Code" />
        </div>
        <p>Thank you for your purchase!</p>
    </div>
</body>
</html>
