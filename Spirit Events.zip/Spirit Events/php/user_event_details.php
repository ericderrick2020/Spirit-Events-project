<?php
require '../php/conn.php';

session_start();

// Validate the ID from the URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Invalid event ID!";
    exit();
}

$id = intval($_GET['id']); // Ensures $id is an integer

// Use a prepared statement to prevent SQL injection
$stmt = $conn->prepare("SELECT * FROM events WHERE event_id = ?");
$stmt->bind_param("i", $id); // 'i' denotes integer type binding
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $event = $result->fetch_assoc();
} else {
    echo "Event not found!";
    exit();
}
$stmt->close();

// Prepare image path for the fetched event
$imagePath = '../assets/img/uploads/' . htmlspecialchars($event['event_images']);

// Process form submission for new events
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // (Existing form submission logic goes here)
}

// Function to handle file uploads
function handleFileUpload($file)
{
    $targetDir = "../assets/img/uploads/";
    $targetFile = $targetDir . basename($file['name']);

    // Move the uploaded file to the target directory
    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        return $targetFile; // Return the path if successful
    } else {
        throw new Exception("Error moving uploaded file.");
    }
}

// Retrieve venue categories for the specific event
$categoriesQuery = "SELECT * FROM event_{$id}_categories"; // Dynamic table name
$categoriesResult = $conn->query($categoriesQuery);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="../assets/css/buyticket.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>

    <main>
        <section class="buy-ticket-section">
            <div class="event-container">
                <div class="event-name">
                    <img src="<?php echo htmlspecialchars($event['event_images']) ?>" alt="Placeholder Image">
                </div>
                <aside class="summarized">
                    <div class="event-name">
                        <h1><?php echo htmlspecialchars($event['event_name']); ?></h1>
                    </div>
                    <!-- <div class="event-motto">
                        <p>Moving in christ</p>
                    </div> -->
                    <div class="event-details">
                        <p><i class="fas fa-calendar-alt"></i> <?php echo htmlspecialchars($event['event_date']); ?></p>
                        <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($event['event_location']); ?></p>
                        <p><i class="fas fa-clock"></i> 7:00 PM - 6:00 AM</p>
                    </div>
                    <form action="payment_page.php" method="get" class="event-buy-opt">
                        <?php if ($categoriesResult && $categoriesResult->num_rows > 0): ?>
                            <?php while ($category = $categoriesResult->fetch_assoc()): ?>
                                <a href="payment-fill-up.php?amount=<?php echo htmlspecialchars($category['cost']); ?>&category=<?php echo htmlspecialchars($category['category_name']); ?>">
                                    <button type="button" value="<?php echo htmlspecialchars($category['category_id']); ?>">
                                        <?php echo htmlspecialchars($category['category_name'] . ' - ' . number_format($category['cost'], 2)); ?>
                                    </button>
                                </a>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p>No categories available</p>
                        <?php endif; ?>
                    </form>
                </aside>
            </div>
        </section>
        <section class="description-section">
            <h1>Description</h1>
            <p><?php echo htmlspecialchars($event['event_description']); ?></p>
        </section>

    </main>

    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.html">Careers</a></li>
                    <li><a href="sponsors.html">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="faqs.html">FAQs</a></li>
                    <li><a href="helpcenter.html">Help Center</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#navbar1">Home</a></li>
                    <li><a href="events.html">Events</a></li>
                    <li><a href="calendar.html">Calendar</a></li>
                    <li><a href="aboutus.html">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SPIRIT EVENTS. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>

    <script src="../assets/js/buyticket.js"></script>
</body>

</html>