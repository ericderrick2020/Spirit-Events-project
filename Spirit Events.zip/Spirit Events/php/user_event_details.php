<?php
require '../php/conn.php';
session_start();

// Validate the ID from the URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Invalid event ID!";
    exit();
}
$id = intval($_GET['id']);  // Ensures $id is an integer

// Use a prepared statement to prevent SQL injection
$stmt = $conn->prepare("SELECT * FROM events WHERE event_id = ?");
$stmt->bind_param("i", $id);  // 'i' denotes integer type binding
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $event = $result->fetch_assoc();
} else {
    echo "Event not found!";
    exit();
}
$stmt->close();

$imagePath = '../assets/img/uploads/' . htmlspecialchars($event['event_images']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Spirit Events</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/buyticket.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbar1" id="navbar1">
        <div class="logo">
            <h2>SimEvents</h2>
        </div>
        <div class="link-to-pages">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
        </div>
        <div class="profile-side">
            <span><?php echo $_SESSION['username']; ?></span>
        </div>
    </nav>

    <main>
        <section class="buy-ticket-section">
            <h1><?php echo $event['event_name']; ?></h1>
            <br>
            <div class="buy-ticket-container">
                <div class="event-name">
                <img src="<?php echo $event['event_images']?>" alt="<?php echo $event['event_name']?>">
                    <br>
                    <p></p>
                    <br>
                    <div class="extra-info">
                        <h3>ABOUT EVENT</h3>
                        <ul>
                            <li><i class="fas fa-calendar-alt"></i> <?php echo $event['event_date'] ?></li>
                            <li><i class="fas fa-clock"></i> 7:00 PM - 10:00 PM</li>
                            <li><i class="fas fa-map-marker-alt"></i> <?php echo $event['event_location'] ?></li>
                        </ul>
                        <p>
                            <?php echo $event['event_description']?>
                        </p>
                    </div>
                </div>

                <div class="event-payment-box">
                    <div class="payment-opt">
                        <h2>Choose Category</h2>
                        <br>
                        <form action="payment-fill-up.php" method="post">
                            <div class="pay-opt-1">
                                <input type="radio" name="Category" id=""> category
                            </div>
                            <div class="pay-opt-1">
                                <input type="radio" name="Category" id=""> category
                            </div>
                            <div class="pay-opt-1">
                                <input type="radio" name="Category" id=""> category
                            </div>
                            <br>
                            <div class="pay-opt">
                                <label for="notick">Number of Tickets</label>
                                <input type="number" name="Category" id="" min = "1"> 
                            </div>
                            <br>
                            <div class="total">
                                <span class="total-mon">Shs. 30000</span>
                            </div>
                            <button type="submit">Buy Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <section class="sponsor-section">
            <h2>Additional Images</h2><br>
            <div class="sponsor-section-container">
                <div class="sponsor-cards">
                    <img src="https://via.placeholder.com/300x200" alt="">
                </div>
                <!-- Repeat sponsor cards as necessary -->
            </div>
        </section>
    </main>

    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.html">Careers</a></li>
                    <li><a href="sponsors.html">Sponsors</a></li>
                    <li><a href="#values">Values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="faqs.html">FAQs</a></li>
                    <li><a href="helpcenter.html">Help Center</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#navbar1">Home</a></li>
                    <li><a href="events.html">Events</a></li>
                    <li><a href="calendar.html">Calendar</a></li>
                    <li><a href="aboutus.html">About</a></li>
                </ul>
            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy; <span id="date"></span> SPIRIT EVENTS. All rights reserved.</p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>

    <script src="../assets/js/buyticket.js"></script>
    <script src="../assets/js/navbarandfooter.js"></script>
</body>

</html>