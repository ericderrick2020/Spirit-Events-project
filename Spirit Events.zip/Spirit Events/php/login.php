<?php
session_start(); // Start session if not started

require '../php/conn.php'; // Include DB connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Prepare the query to fetch user data by username
    $stmt = $conn->prepare("SELECT username, user_password FROM users WHERE username = ?");
    if (!$stmt) {
        die("Query preparation failed: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc(); // Fetch user data

        // Verify password against hashed password
        if (password_verify($password, $user['user_password'])) {
            // Store user info in session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

            // Redirect to dashboard or home page
            header("Location: ../php/user_index.php");
            exit(); // Stop further script execution
        } else {
            echo "<script>alert('Invalid username or password.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('User not found.'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
