<?php
require '../php/conn.php';
session_start();

if (!isset($_POST['id'])) {
    die("ID not provided.");
}

$id = $_POST['id'];


$sql = "DELETE FROM events WHERE event_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: ./dashboard_event.php");
    exit(); // Stop further script execution after redirect
} else {
    echo "Error deleting record: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
