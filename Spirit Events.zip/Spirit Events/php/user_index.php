<?php
include 'conn.php';
session_start();

// Redirect to login if the user is not logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

// Prepare a statement to fetch the user profile
$query = $conn->prepare("SELECT * FROM users WHERE username = ?");
$query->bind_param("s", $_SESSION['username']);
$query->execute();

// Fetch the result correctly
$outcome = $query->get_result();  // Correct function name is get_result() (lowercase "r")

// Check if a user was found and fetch profile picture
if ($outcome && $outcome->num_rows > 0) {
    $row = $outcome->fetch_assoc();
    $profilePic = $row['profile_pic'];
} else {
    $profilePic = "../assets/img/profile-pics/default-profile.jpg";
}
$query->close();

// For cards: Execute a query to fetch event information
$query_2 = "SELECT event_images, event_name, event_date, event_location, event_category, event_description FROM events";
$results_of_query_2 = $conn->query($query_2);

if (!$results_of_query_2) {
    die("Error fetching events: " . $conn->error);
}

$conn->close();
?>


<!-- https://via.placeholder.com/300x200 -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- WEBSITE TITLE -->
    <title>Home | Spirit Events</title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/index.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbargen">
        <div class="navbartop">
            <i class="fa-solid fa-bars" id="icon" onclick="mobileNavViewer()"></i>
            <div class="logo">
                <h1><span>Sim</span>Events</h1>
            </div>
            <div class="profile-images">
                <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
            </div>
            <!-- <img src="../assets/img/profile-pics/" alt=""> -->
        </div>
        <div class="navbar1" id="bars">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
            <a href="user-contacts.php">
                <div class="navbtn">
                    Contact Us
                </div>
            </a>
        </div>
    </nav>
    <main>
        <!-- HERO SECTION START -->
        <section class="hero-section">
            <div class="hero-sec-bgc">
                <div class="hero-sec-bgc-1">
                    <h1>WE ARE SPIRIT EVENTS</h1>
                    <p>Join us for an inspiring Christian event filled with worship, powerful teachings, and fellowship
                        as we come together to celebrate faith and hope</p>
                    <br>
                    <button class="btn">Get Tickets</button>
                </div>
                <div class="hero-sec-bgc-2">
                    <img src="https://via.placeholder.com/300x200" alt="Rectangle Placeholder Image">
                </div>
            </div>
        </section>
        <!-- HERO SECTION CLOSE -->

        <!-- FEATURED EVENTS START -->
        <section class="featured-events">
            <h2>Featured Events</h2>
            <br>
            <div class="event-cards-container">
                <?php
                $limit = 3; // Set the limit once outside the loop
                $count = 0;

                while ($event = $results_of_query_2->fetch_assoc()):
                    if ($count >= $limit) {
                        break; // Stop the loop if the limit is reached
                    }
                ?>
                    <div class="event-cards">
                        <img src="<?php echo htmlspecialchars($event['event_images']) ?>" alt="Placeholder Image">
                        <div class="event-card-info-pos">
                            <div class="event-card-document">
                                <h3><?php echo htmlspecialchars($event['event_name']) ?></h3>
                                <p><i class="fa-solid fa-location-dot"></i> Lugogo Cricket Oval </p>
                            </div>
                            <div class="event-card-button">
                                <time datetime=""><i class="fa-solid fa-calendar-days"></i> July 15-17,2025</time>
                            </div>
                        </div>
                    </div>
                <?php
                    $count++; // Increment the count after displaying an event
                endwhile;
                ?>
                <!-- <a href="user_events.php"><button class = "learn_more">LEARN MORE</button></a> -->
            </div>
        </section>
        <!-- FEATURED EVENTS CLOSE -->
        <!-- UPCOMING EVENTS START -->
        <!-- <section class="upcoming-events">
            <h2>Upcoming Events</h2>
            <br>
            <div class="upcoming-events-container">
                <div class="upcoming-events-card">
                    <div class="profile-img">
                        <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
                        <div class="upcoming-events-information">
                            <h3>End of year party</h3>
                            <div class="upcoming-events-information">
                                <time datetime="">March 10, 2025</time>
                                <span>Online</span>
                            </div>
                        </div>
                    </div>
                    <a href=""><button>RSVP</button></a>
                </div>

                <div class="upcoming-events-card">
                    <div class="profile-img">
                        <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
                        <div class="upcoming-events-information">
                            <h3>End of year party</h3>
                            <div class="upcoming-events-information">
                                <time datetime="">March 10, 2025</time>
                                <span>Online</span>
                            </div>
                        </div>
                    </div>
                    <a href=""><button>RSVP</button></a>
                </div>

                <div class="upcoming-events-card">
                    <div class="profile-img">
                        <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
                        <div class="upcoming-events-information">
                            <h3>End of year party</h3>
                            <div class="upcoming-events-information">
                                <time datetime="">March 10, 2025</time>
                                <span>Online</span>
                            </div>
                        </div>
                    </div>
                    <a href=""><button>RSVP</button></a>
                </div>
            </div>
        </section> -->
        <!-- UPCOMING EVENTS END -->
    </main>
    <!-- FOOTER START -->
    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.html">Careers</a></li>
                    <li><a href="sponsors.html">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="faqs.html">FAQs</a></li>
                    <li><a href="helpcenter.html">Help Center</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#navbar1">Home</a></li>
                    <li><a href="events.html">Events</a></li>
                    <li><a href="calendar.html">Calendar</a></li>
                    <li><a href="aboutus.html">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SPIRIT EVENTS. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>
    <!-- FOOTER END -->
    <!-- JAVASCRIPT LINKS -->
    <script src="../assets/js/navbarandfooter.js"></script>
</body>

</html>