<?php
require '../php/conn.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collecting data from form
    $eventId = $_POST['id'];
    $eventname = $_POST['event-name'];
    $eventdate = $_POST['date'];
    $event_location = $_POST['Location-name'];
    $event_description = $_POST['describe'];

    // Handle image upload
    $image_path = ""; // Variable to store the image path

    // Check if a new image has been uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $targetDir = "../assets/img/uploads/"; // Ensure this directory exists and is writable
        $targetFile = $targetDir . basename($_FILES['image']['name']); // Get the file path

        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $image_path = $targetFile; // Set the new image path
        } else {
            echo "Error moving uploaded file.";
            exit();
        }
    } else {
        // If no new image is uploaded, we need to keep the old image path
        // Fetch the current image path
        $sql = "SELECT event_images FROM events WHERE event_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $eventId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $image_path = $row['event_images']; // Retain the current image path
        } else {
            echo "No existing event found.";
            exit();
        }
        $stmt->close();
    }

    // Update the event in the database
    $sql = "UPDATE events SET event_images = ?, event_name = ?, event_date = ?, event_location = ?, event_description = ? WHERE event_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $image_path, $eventname, $eventdate, $event_location, $event_description, $eventId);

    if ($stmt->execute()) {
        // Redirect to the events dashboard after a successful update
        header("Location: ./dashboard_event.php");
        exit();
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dasboard_general.css">
    <script defer src="../assets/js/dashboard_general.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard_add_event.css">
</head>

<body>
    <div class="dashboard">
        <nav class="sidebar">
            <div class="logo-title">
                <h2>Events Dashboard</h2>
            </div>
            <ul class="nav-links">
                <li><a href="./dashboard_home.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="./dashboard_event.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                <li><a href="#"><i class="fas fa-ticket-alt"></i> Bookings</a></li>
                <li><a href="#"><i class="fas fa-money-bill-wave"></i> Payments</a></li>
                <li><a href="#"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="#"><i class="fas fa-chart-line"></i> Reports</a></li>
                <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="#"><i class="fas fa-envelope"></i> Messages</a></li>
                <li><a href="#"><i class="fas fa-bullhorn"></i> Alerts</a></li>
                <li><a href="#"><i class="fas fa-file-export"></i> Export</a></li>
                <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <section class="content-box">
            <nav class="heading">
                <h1>Edit Event</h1>
            </nav>
            <div class="content-container">
                <div class="page-heading">
                    <h2>Events info</h2>
                </div>
                <div class="content-container-general">
                    <form method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $eventId; ?>"> <!-- Hidden input for event ID -->
                        <div class="add-event-page-container-1">
                            <div id="imageDisplay">
                                <img src="<?php echo htmlspecialchars($image_path); ?>" alt="Current Event Image" style="max-width: 100px; max-height: 100px;">
                            </div>
                            <input type="file" name="image" id="imageInput" accept="image/*">
                        </div>
                        <div class="add-event-page-container-2">
                            <div class="row-1">
                                <label for="event-name">Event Name</label>
                                <input type="text" name="event-name" id="event-name" value="<?php echo htmlspecialchars($eventname); ?>" required>
                            </div>
                            <div class="row-1">
                                <label for="date">Date</label>
                                <input type="date" name="date" id="date" value="<?php echo htmlspecialchars($eventdate); ?>" required>
                            </div>
                            <div class="row-1">
                                <label for="Location-name">Location</label>
                                <input type="text" name="Location-name" id="Location-name" value="<?php echo htmlspecialchars($event_location); ?>" required>
                            </div>
                            <div class="row-1">
                                <div id="addBtn">Add venue</div>
                                <div id="inputContainer"></div>
                            </div>
                            <div class="row-1">
                                <label for="describe">Description</label>
                                <textarea name="describe" id="describe" required><?php echo htmlspecialchars($event_description); ?></textarea>
                            </div>
                            <button type="submit" name="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
    <script src="../assets/js/dashboard_add_event.js"></script>
</body>

</html>
