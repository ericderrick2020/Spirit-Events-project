<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if the user is logged in
// if (!isset($_SESSION['user_id'])) {
//     header("Location: ../html/login-page.html");
//     exit;
// }

// Database connection credentials
$host = '127.0.0.1';
$username = 'root'; // Replace if necessary
$password = 'ericderrick2020'; // Replace if necessary
$dbname = 'event_login'; // Replace with your database name

// Create the MySQL connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Execute the query to get the number of users
$sql = "SELECT COUNT(username) AS user_count FROM users";
$result = $conn->query($sql);

$sql1 = "SELECT COUNT(DISTINCT event_name) AS event_counts FROM events";
$result1 = $conn ->query($sql1);

// Check if the query executed successfully
if ($result) {
    $noOfUsers = $result->fetch_assoc()['user_count'] ?? 0;
} else {
    die("Query failed: " . $conn->error);
}

if ($result1) {
    $noOfUsers1 = $result1->fetch_assoc()['event_counts'] ?? 0;
} else {
    die("Query failed: " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dasboard_general.css">
    <script defer src="../assets/js/dashboard_general.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard_home.css">
</head>

<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="logo-title">
                <h2>Events Dashboard</h2>
            </div>
            <ul class="nav-links">
                <li><a href="dashboard_home.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="dashboard_event.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                <li><a href="#"><i class="fas fa-ticket-alt"></i> Bookings</a></li>
                <li><a href="#"><i class="fas fa-money-bill-wave"></i> Payments</a></li>
                <li><a href="#"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="#"><i class="fas fa-chart-line"></i> Reports</a></li>
                <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="#"><i class="fas fa-envelope"></i> Messages</a></li>
                <li><a href="#"><i class="fas fa-bullhorn"></i> Alerts</a></li>
                <li><a href="#"><i class="fas fa-file-export"></i> Export</a></li>
                <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <!-- CONTENT SIDE OPEN -->
        <section class="content-box">
            <nav class="heading">
                <h1>HOME PAGE</h1>
            </nav>
            <div class="content-container">
                <div class="page-heading">
                    <h2>Overview</h2>
                </div>
                <div class="home-container-container">
                    <div class="home-page-container">
                        <div class="metrics-box">
                            <div class="layer-1">
                                <h3>Total Events</h3>
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div class="layer-2">
                                <span><?php echo $noOfUsers1;?></span>
                            </div>
                            <div class="layer-3">
                                <span>+12% from last month</span>
                            </div>
                        </div>
                    </div>

                    <div class="home-page-container">
                        <div class="metrics-box">
                            <div class="layer-1">
                                <h3>Tickets sold</h3>
                                <i class="fas fa-ticket-alt"></i>
                            </div>
                            <div class="layer-2">
                                <span>11248</span>
                            </div>
                            <div class="layer-3">
                                <span>+12% from last month</span>
                            </div>
                        </div>
                    </div>

                    <div class="home-page-container">
                        <div class="metrics-box">
                            <div class="layer-1">
                                <h3>Users</h3>
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div class="layer-2">
                                <span><?php echo $noOfUsers; ?></span>
                            </div>
                            <div class="layer-3">
                                <span>+12% from last month</span>
                            </div>
                        </div>
                    </div>

                    <div class="home-page-container">
                        <div class="metrics-box">
                            <div class="layer-1">
                                <h3>Attendants</h3>
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div class="layer-2">
                                <span>9248</span>
                            </div>
                            <div class="layer-3">
                                <span>+12% from last month</span>
                            </div>
                        </div>
                    </div>

                    <div class="home-page-container">
                        <div class="metrics-box">
                            <div class="layer-1">
                                <h3>Revenue</h3>
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div class="layer-2">
                                <span>Shs.245648</span>
                            </div>
                            <div class="layer-3">
                                <span>+12% from last month</span>
                            </div>
                        </div>
                    </div>

                    <div class="home-page-container">
                        <div class="metrics-box">
                            <div class="layer-1">
                                <h3>Upcoming Events</h3>
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div class="layer-2">
                                <span>848</span>
                            </div>
                            <div class="layer-3">
                                <span>+12% from last month</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- CONTENT SIDE CLOSE -->
    </div>

    <!-- Main Content -->
</body>

</html>