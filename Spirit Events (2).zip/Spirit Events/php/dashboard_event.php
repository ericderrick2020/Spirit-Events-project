<?php
require '../php/conn.php';
session_start();

// Fetch events from the database, including event_id
$sql = "SELECT event_id, event_images, event_name, event_date, event_location, event_description FROM events";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dasboard_general.css">
    <script defer src="../assets/js/dashboard_general.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard_event.css">
</head>

<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="logo-title">
                <h2>Events Dashboard</h2>
            </div>
            <ul class="nav-links">
                <li><a href="./dashboard_home.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="./dashboard_event.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                <li><a href="#"><i class="fas fa-ticket-alt"></i> Bookings</a></li>
                <li><a href="#"><i class="fas fa-money-bill-wave"></i> Payments</a></li>
                <li><a href="#"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="#"><i class="fas fa-chart-line"></i> Reports</a></li>
                <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="#"><i class="fas fa-envelope"></i> Messages</a></li>
                <li><a href="#"><i class="fas fa-bullhorn"></i> Alerts</a></li>
                <li><a href="#"><i class="fas fa-file-export"></i> Export</a></li>
                <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>

        <!-- CONTENT SIDE OPEN -->
        <section class="content-box">
            <nav class="heading">
                <h1>EVENT PAGE</h1>
            </nav>
            <div class="content-container">
                <div class="page-heading">
                    <h2>Current Events</h2>
                    <a href="./dashboard_add_event.php"><button><i class="fas fa-calendar-plus"></i> Add Event</button></a>
                </div>

                <div class="page-content">
                    <div class="card-box-for-events">
                        <?php if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) { ?>
                                <div class="event-card-for-admin">
                                    <img src="<?php echo $row['event_images']; ?>" alt="Event Image">
                                    <div class="event-card-for-admin-side-1">
                                        <h2><?php echo $row['event_name']; ?></h2>
                                        <p><?php echo $row['event_description']; ?></p>
                                        <small>Date: <?php echo $row['event_date']; ?></small>
                                    </div>
                                    <div class="event-card-for-admin-side-3">
                                        <!-- Edit Button -->
                                        <a href="dashboard_event_edit.php?id=<?php echo $row['event_id']; ?>"> Edit</a>
                                        <!-- Delete Button -->
                                        <form action="./delete_event_for_dashboard.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="id" value="<?php echo $row['event_id']; ?>">
                                            <button type="submit" onclick="return confirm('Are you sure you want to delete this event?')">
                                                <i class="fas fa-trash"></i> DELETE
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php }
                        } else { ?>
                            <p>No events found!</p>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
</body>

</html>