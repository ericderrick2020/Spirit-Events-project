<?php
$host = '127.0.0.1';
$user = 'root'; // Replace if necessary
$password = 'ericderrick2020'; // Replace if necessary
$dbname = 'event_login';

// Create MySQLi connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
