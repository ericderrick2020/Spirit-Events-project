<?php
// Database connection
require '../php/conn.php';
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Fetch events from the database
$query = "SELECT * FROM events ORDER BY updated_at ASC";
$result = $conn->query($query);

$events = [];
if ($result->num_rows > 0) {
    // Fetch all events and convert BLOBs to base64 strings
    while ($row = $result->fetch_assoc()) {
        if (!is_null($row['event_images'])) {
            // $row['event_images'] = base64_decode($row['event_images']);
        }
        $events[] = $row;
    }
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/events.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar1" id="navbar1">
        <div class="logo">
            <h2>SimEvents</h2>
        </div>
        <div class="link-to-pages">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
        </div>
        <div class="profile-side">
            <span><?php echo $_SESSION['username']; ?></span>
        </div>
    </nav>

    <main>
        <div class="container" id="events-container">
            <h2>Featured Events</h2>
            <div class="filter-container">
                <select id="eventFilter">
                    <option value="all">All</option>
                    <option value="thisYear">This Year</option>
                    <option value="past">Past</option>
                    <option value="upcoming">Upcoming</option>
                </select>
                <input type="text" id="searchBar" placeholder="Search events...">
            </div>

            <div class="card-container" id="card-container">

            </div>

            <div class="pagination">
                <button id="prev">Previous</button>
                <button id="next">Next</button>
            </div>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="aboutus.html#team">Team</a></li>
                    <li><a href="crew.html">Careers</a></li>
                    <li><a href="sponsors.html">Sponsors</a></li>
                    <li><a href="#values">Values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="faqs.html">FAQs</a></li>
                    <li><a href="helpcenter.html">Help Center</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="#events-container">Events</a></li>
                    <li><a href="calendar.html">Calendar</a></li>
                    <li><a href="aboutus.html">About</a></li>
                </ul>
            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#"><i class="fa-brands fa-x-twitter"></i></a>
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy; <span id="date"></span> SPIRIT EVENTS. All rights reserved.</p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>

    <script>
        const events = <?php echo json_encode($events); ?>;
        const cardsPerPage = 9;
        let currentPage = 1;
        let filteredEvents = events;
        console.log(events);

        function displayCards() {
            const cardContainer = document.getElementById("card-container");
            cardContainer.innerHTML = "";

            const startIndex = (currentPage - 1) * cardsPerPage;
            const endIndex = startIndex + cardsPerPage;
            const currentEvents = filteredEvents.slice(startIndex, endIndex);

            currentEvents.forEach(event => {
                const card = document.createElement("div");
                card.className = "card";
                card.innerHTML = `
                    <img src="${event.event_images}" alt="Event1 Image">
                    <div class="event-card-info-pos">
                        <div class="event-card-document">
                           <h3>${event.event_name}</h3>
                           <p class="event-location"><i class="fa-solid fa-location-dot"></i> ${event.event_location}</p>
                        </div>
                        <div class="event-card-button">
                        <p class="event-date"><i class="fa-solid fa-calendar"></i> ${new Date(event.event_date).toLocaleDateString()}</p>
                           <a href=""><button><i class="fa-solid fa-ticket"></i> Get Ticket</button></a>
                        </div>
                    </div>
                    `;
                cardContainer.appendChild(card);
            });
        }

        function updatePagination() {
            const totalPages = Math.ceil(filteredEvents.length / cardsPerPage);
            document.getElementById("prev").disabled = currentPage === 1;
            document.getElementById("next").disabled = currentPage === totalPages;
        }

        function filterEvents() {
            const filterValue = document.getElementById("eventFilter").value;
            const searchValue = document.getElementById("searchBar").value.toLowerCase();

            filteredEvents = events.filter(event => {
                const eventDate = new Date(event.event_date);
                const matchesSearch = event.event_name.toLowerCase().includes(searchValue);

                switch (filterValue) {
                    case "thisYear":
                        return eventDate.getFullYear() === new Date().getFullYear() && matchesSearch;
                    case "past":
                        return eventDate < new Date() && matchesSearch;
                    default:
                        return matchesSearch;
                }
            });

            currentPage = 1;
            displayCards();
            updatePagination();
        }

        document.getElementById("eventFilter").addEventListener("change", filterEvents);
        document.getElementById("searchBar").addEventListener("input", filterEvents);
        document.getElementById("prev").addEventListener("click", () => {
            if (currentPage > 1) currentPage--;
            displayCards();
            updatePagination();
        });
        document.getElementById("next").addEventListener("click", () => {
            if (currentPage < Math.ceil(filteredEvents.length / cardsPerPage)) currentPage++;
            displayCards();
            updatePagination();
        });

        displayCards();
        updatePagination();
    </script>
</body>

</html>