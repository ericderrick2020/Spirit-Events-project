<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- WEBSITE TITLE -->
    <title>Home | Spirit Events</title>
    <!-- FONT FAMILIES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <!-- ICON LINKS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- LINKS FOR CSS -->
    <link rel="stylesheet" href="../assets/css/index.css">
    <link rel="stylesheet" href="../assets/css/navbarandfooter.css">
</head>

<body>
    <nav class="navbar1" id="navbar1">
        <div class="logo">
            <h2>SimEvents</h2>
        </div>
        <div class="link-to-pages">
            <ul>
                <li><a href="user_index.php">Home</a></li>
                <li><a href="user_events.php">Events</a></li>
                <li><a href="user_calendar.php">Calendar</a></li>
                <li><a href="user_aboutus.php">About</a></li>
            </ul>
        </div>
        <div class="profile-side">
            <span><?php echo $_SESSION['username']; ?></span>
        </div>
    </nav>
    <!-- HERO SECTION START -->
    <main>
    <div class="hero-section">
            <div class="hero-content">
                <h2>Discover and attend amazing events</h2>
                <p>Easily follow our hot events in the zone</p>
                <a href=""><button>EXPLORE MORE</button></a>
            </div>
            <div class="hero-image">
                <img src="../assets/img/LandscapevsPortraitOrientationWhatistheDifference.webp" alt="hero-section">
            </div>
        </div>
        <!-- HERO SECTION CLOSE -->

        <!-- FEATURED EVENTS START -->
        <section class="featured-events">
            <h2>Featured Events</h2>
            <br>
            <div class="event-cards-container">
                <div class="event-cards">
                    <img src="../assets/img/party_3.jpg" alt="Placeholder Image">
                    <div class="event-card-info-pos">
                        <div class="event-card-document">
                            <h3>Spirit vibes</h3>
                            <a href=""><i class="fa-solid fa-location-dot"></i> Lugogo Cricket Oval</a>
                        </div>
                        <div class="event-card-button">
                            <time datetime=""><i class="fa-solid fa-calendar-days"></i> July 15-17,2025</time>
                            <a href=""><button><i class="fa-solid fa-ticket"></i> Get Ticket</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- FEATURED EVENTS CLOSE -->
        <!-- UPCOMING EVENTS START -->
        <section class="upcoming-events">
            <h2>Upcoming Events</h2>
            <br>
            <div class="upcoming-events-container">
                <div class="upcoming-events-card">
                    <div class="profile-img">
                        <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
                        <div class="upcoming-events-information">
                            <h3>End of year party</h3>
                            <div class="upcoming-events-information">
                                <time datetime="">March 10, 2025</time>
                                <span>Online</span>
                            </div>
                        </div>
                    </div>
                    <a href=""><button>RSVP</button></a>
                </div>

                <div class="upcoming-events-card">
                    <div class="profile-img">
                        <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
                        <div class="upcoming-events-information">
                            <h3>End of year party</h3>
                            <div class="upcoming-events-information">
                                <time datetime="">March 10, 2025</time>
                                <span>Online</span>
                            </div>
                        </div>
                    </div>
                    <a href=""><button>RSVP</button></a>
                </div>

                <div class="upcoming-events-card">
                    <div class="profile-img">
                        <img src="https://via.placeholder.com/300x200" alt="Placeholder Image">
                        <div class="upcoming-events-information">
                            <h3>End of year party</h3>
                            <div class="upcoming-events-information">
                                <time datetime="">March 10, 2025</time>
                                <span>Online</span>
                            </div>
                        </div>
                    </div>
                    <a href=""><button>RSVP</button></a>
                </div>
            </div>
        </section>
        <!-- UPCOMING EVENTS END -->

    </main>
    <!-- FOOTER START -->
    <footer>
        <div class="footer-container">
            <div class="side-1">
                <h3>About</h3>
                <ul>
                    <li><a href="#team">Team</a></li>
                    <li><a href="crew.html">Careers</a></li>
                    <li><a href="sponsors.html">Sponsors</a></li>
                    <li><a href="#values">values</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Support</h3>
                <ul>
                    <li><a href="faqs.html">FAQs</a></li>
                    <li><a href="helpcenter.html">Help Center</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
            </div>
            <div class="side-1">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#navbar1">Home</a></li>
                    <li><a href="events.html">Events</a></li>
                    <li><a href="calendar.html">Calendar</a></li>
                    <li><a href="aboutus.html">About</a></li>
                </ul>

            </div>
            <div class="side-2">
                <h3>Follow Us</h3>
                <div class="media">
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                    <a href=""><i class="fa-brands fa-x-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-credits">
            <p>&copy;
                <span id="date"></span> SPIRIT EVENTS. All rights reserved.
            </p>
            <span>Created by Nahabwe Derrick Eric</span>
        </div>
    </footer>
    <!-- FOOTER END -->
    <!-- JAVASCRIPT LINKS -->
    <script src="../assets/js/navbarandfooter.js"></script>
</body>

</html>